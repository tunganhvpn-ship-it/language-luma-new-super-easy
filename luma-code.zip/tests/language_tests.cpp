#include <functional>
#include <iostream>
#include <sstream>
#include <string>
#include <utility>

#include "luma/bytecode/compiler.hpp"
#include "luma/core/diagnostic.hpp"
#include "luma/lex/lexer.hpp"
#include "luma/parse/parser.hpp"
#include "luma/runtime/vm.hpp"

namespace
{

    std::string execute(const std::string &source)
    {
        const auto tokens = luma::Lexer{source}.scan();
        const auto program = luma::Parser{tokens}.parse();
        const auto chunk = luma::Compiler{}.compile(program);
        std::ostringstream output;
        auto *const previous = std::cout.rdbuf(output.rdbuf());
        try
        {
            luma::VirtualMachine{}.run(chunk);
        }
        catch (...)
        {
            std::cout.rdbuf(previous);
            throw;
        }
        std::cout.rdbuf(previous);
        return output.str();
    }

    bool check(bool condition, std::string_view name)
    {
        if (condition)
            return true;
        std::cerr << "FAILED: " << name << '\n';
        return false;
    }

}

int run_language_tests()
{
    int failures = 0;

    // ── Python-like syntax (v0.6) ──────────────────────────────────────
    failures += !check(execute("value = 2 + 3 * 4\nprint(value)\n") == "14\n", "arithmetic precedence");
    failures += !check(execute("if False:\n    print(\"no\")\nelse:\n    print(\"yes\")\n") == "yes\n", "if/else");
    failures += !check(execute("def add(a, b):\n    return a + b\nprint(add(2, 3))\n") == "5\n", "function call");
    failures += !check(execute("total = 0\nfor n in [1, 2, 3]:\n    total = total + n\nprint(total)\n") == "6\n",
                        "for loop over list");
    failures += !check(execute("n = 0\nwhile n < 3:\n    print(n)\n    n = n + 1\n") == "0\n1\n2\n", "while loop");
    failures += !check(execute("def fact(n):\n    if n <= 1:\n        return 1\n    return n * fact(n - 1)\n"
                                "print(fact(5))\n") == "120\n",
                        "recursive function");
    failures += !check(execute("if 1 < 2:\n    print(\"a\")\nelif 1 > 2:\n    print(\"b\")\nelse:\n    print(\"c\")\n") ==
                            "a\n",
                        "if/elif/else");
    failures += !check(execute("n = 1\nn += 4\nn *= 2\nn -= 3\nprint(n)\n") == "7\n", "compound assignment");
    failures += !check(execute("print(2 ** 10)\n") == "1024\n", "power operator");
    failures += !check(execute("items = [1, 2, 3]\nitems[1] = 9\nprint(items[1])\n") == "9\n", "index assignment");
    failures += !check(execute("for n in [1, 2, 3, 4]:\n    if n == 3:\n        break\n    print(n)\n") == "1\n2\n",
                        "break in for loop");
    failures += !check(execute("for n in [1, 2, 3]:\n    if n == 2:\n        continue\n    print(n)\n") == "1\n3\n",
                        "continue in for loop");
    failures += !check(execute("n = 0\nwhile True:\n    n += 1\n    if n >= 3:\n        break\nprint(n)\n") ==
                            "3\n",
                        "break in while loop");
    failures += !check(execute("items = [3, 1, 2]\nsort(items)\nprint(items)\n") == "[1, 2, 3]\n", "sort builtin");
    failures += !check(execute("a = 1; b = 2; print(a + b)\n") == "3\n", "semicolon separators");
    failures += !check(execute("if 2 > 1: print(\"yes\")\nelse: print(\"no\")\n") == "yes\n", "inline suite");
    failures += !check(execute("if True: print(1); print(2)\nprint(3)\n") == "1\n2\n3\n", "inline suite with semicolon");
    failures += !check(execute("if True: pass\nprint(1)\n") == "1\n", "pass statement");
    failures += !check(execute("print(sum([1, 2, 3]))\n") == "6\n", "sum builtin");
    failures += !check(execute("print(slice(\"hello\", 1, 3))\n") == "el\n", "slice builtin");
    failures += !check(execute("print(replace(\"aaa\", \"a\", \"b\"))\n") == "bbb\n", "replace builtin");
    failures += !check(execute("print(find([4, 5, 6], 5))\n") == "1\n", "find builtin");
    failures += !check(execute("print(trim(\"  hi  \"))\n") == "hi\n", "trim builtin");
    failures += !check(execute("print(clamp(15, 0, 10))\n") == "10\n", "clamp builtin");
    failures += !check(execute("for i in range(1, 6):\n    print(i)\n") == "1\n2\n3\n4\n5\n", "range loop");
    failures += !check(execute("for i in range(10, 0, -3):\n    print(i)\n") == "10\n7\n4\n1\n",
                        "range loop with step");
    failures += !check(execute("for i in range(1, 6):\n    if i == 3: continue\n    print(i)\n") == "1\n2\n4\n5\n",
                        "continue in range loop");
    failures += !check(execute("x = 0\nwhile not x >= 3:\n    x += 1\nprint(x)\n") == "3\n", "while not");
    failures += !check(execute("n = 0\nwhile True:\n    n += 1\n    if n == 4: break\nprint(n)\n") == "4\n",
                        "while True + break");

    // ── Legacy Luma aliases (backward compat) ──────────────────────────
    failures += !check(execute("let value = 2 + 3 * 4\nprint(value)\n") == "14\n", "legacy let");
    failures += !check(execute("print(\"hello\")\n") == "hello\n", "print builtin");
    failures += !check(execute("when False:\n    print(\"no\")\notherwise:\n    print(\"yes\")\n") == "yes\n", "legacy when/otherwise");
    failures += !check(execute("func add(a, b):\n    return a + b\nprint(add(2, 3))\n") == "5\n", "legacy func");
    failures += !check(execute("repeat 3:\n    print(\"x\")\n") == "x\nx\nx\n", "legacy repeat loop");
    failures += !check(execute("n = 0\nuntil n >= 3:\n    n += 1\nprint(n)\n") == "3\n", "legacy until");
    failures += !check(execute("n = 0\nforever:\n    n += 1\n    if n == 4: break\nprint(n)\n") == "4\n", "legacy forever");
    failures += !check(execute("for i in 1 to 5:\n    print(i)\n") == "1\n2\n3\n4\n5\n", "legacy counting loop");
    failures += !check(execute("for i in 10 to 1 step -3:\n    print(i)\n") == "10\n7\n4\n1\n", "legacy counting loop with step");
    failures += !check(execute("for i in 1 to 5:\n    if i == 3: continue\n    print(i)\n") == "1\n2\n4\n5\n",
                        "continue in legacy counting loop");
    failures += !check(execute("n = 0\nrepeat 5:\n    n += 1\n    if n == 2: break\nprint(n)\n") == "2\n",
                        "break in legacy repeat loop");

    // ── New Python-like features ───────────────────────────────────────
    failures += !check(execute("x = lambda a, b: a + b\nprint(x(3, 4))\n") == "7\n", "lambda");
    failures += !check(execute("print(10 if True else 20)\n") == "10\n", "ternary expression");
    failures += !check(execute("items = [1, 2, 3, 4, 5]\nresult = [x for x in items if x > 2]\nprint(result)\n") == "[3, 4, 5]\n", "list comprehension");

    // ── Error diagnostics ──────────────────────────────────────────────
    bool reported = false;
    try
    {
        const auto tokens = luma::Lexer{"if True\n    print(\"x\")\n"}.scan();
        static_cast<void>(luma::Parser{tokens}.parse());
    }
    catch (const luma::Diagnostic &)
    {
        reported = true;
    }
    failures += !check(reported, "syntax diagnostic");
    return failures;
}
