#pragma once

#include "luma/ast/ast.hpp"
#include "luma/bytecode/chunk.hpp"

namespace luma
{

    // Compiles a parsed program to Luma bytecode.
    // The result can run directly on the VM or be saved to a `.lumac` file.
    class Compiler
    {
    public:
        [[nodiscard]] Chunk compile(const Program &program);

    private:
        // Tracks the innermost enclosing loop so `break`/`continue` know
        // where to jump (and which runtime loop bookkeeping to unwind).
        struct LoopContext
        {
            enum class Kind
            {
                while_loop,
                for_loop,
            };
            Kind kind;
            std::vector<std::size_t> break_jumps;
            std::vector<std::size_t> continue_jumps;
        };

        void compile_block(const StmtList &body);
        void compile_statement(const Stmt &statement);
        void compile_expression(const Expr &expression);

        Chunk chunk_;
        std::vector<LoopContext> loops_;
        std::size_t temp_counter_{0};
    };

}
