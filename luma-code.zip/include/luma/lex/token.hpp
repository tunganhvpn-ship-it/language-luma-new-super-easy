#pragma once

#include <string>
#include <string_view>

#include "luma/core/source.hpp"

namespace luma
{

    enum class TokenKind
    {
        // ── Structural ──────────────────────────────────────────────────
        end,
        newline,
        indent,
        dedent,

        // ── Literals and names ──────────────────────────────────────────
        identifier,
        number,
        text,            // "..." or '...'
        fstring,         // f"..." or f'...'
        long_text,       // """...""" or '''...'''
        long_fstring,    // f"""..."""

        // ── Python keywords (alphabetical) ──────────────────────────────
        and_keyword,
        as_keyword,
        assert_keyword,
        async_keyword,
        await_keyword,
        break_keyword,
        class_keyword,
        continue_keyword,
        def_keyword,
        del_keyword,
        elif_keyword,
        else_keyword,
        except_keyword,
        finally_keyword,
        for_keyword,
        from_keyword,
        global_keyword,
        if_keyword,
        import_keyword,
        in_keyword,
        is_keyword,
        lambda_keyword,
        nonlocal_keyword,
        not_keyword,
        or_keyword,
        pass_keyword,
        raise_keyword,
        return_keyword,
        try_keyword,
        while_keyword,
        with_keyword,
        yield_keyword,

        // ── Python literals ─────────────────────────────────────────────
        true_keyword,    // True
        false_keyword,   // False
        none_keyword,    // None

        // ── Delimiters ──────────────────────────────────────────────────
        left_paren,      // (
        right_paren,     // )
        left_bracket,    // [
        right_bracket,   // ]
        left_brace,      // {
        right_brace,     // }
        colon,           // :
        semicolon,       // ;
        comma,           // ,
        dot,             // .
        at,              // @  (decorators)
        arrow,           // -> (return type hint, lambda)
        ellipsis,        // ...
        walrus,          // := (walrus operator)

        // ── Operators ───────────────────────────────────────────────────
        plus,            // +
        minus,           // -
        star,            // *
        star_star,       // **
        slash,           // /
        double_slash,    // //
        percent,         // %
        at_op,           // @  (matrix multiply)

        // ── Assignment operators ────────────────────────────────────────
        equal,           // =
        plus_equal,      // +=
        minus_equal,     // -=
        star_equal,      // *=
        slash_equal,     // /=
        double_slash_equal, // //=
        percent_equal,   // %=
        star_star_equal, // **=
        at_equal,        // @=

        // ── Comparison operators ────────────────────────────────────────
        equal_equal,     // ==
        bang_equal,      // !=
        less,            // <
        less_equal,      // <=
        greater,         // >
        greater_equal,   // >=

        // ── Bitwise operators ───────────────────────────────────────────
        ampersand,       // &
        pipe,            // |
        caret,           // ^
        tilde,           // ~
        left_shift,      // <<
        right_shift,     // >>

        // ── Increment/Decrement ─────────────────────────────────────────
        plus_plus,       // ++
        minus_minus,     // --
    };

    struct Token
    {
        TokenKind kind;
        std::string lexeme;
        SourceLocation location;
    };

    std::string_view token_name(TokenKind kind);

}
