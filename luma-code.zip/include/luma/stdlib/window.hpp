#pragma once

// Minimal window/2D-render surface used by the `window_*` Luma built-ins.
// Backed by SDL2 when it was available at build time (see CMakeLists.txt,
// which defines LUMA_HAVE_SDL2). Without SDL2 every function degrades to a
// harmless no-op so programs still compile and run headless.

#include <string>

namespace luma::stdlib::window
{

    [[nodiscard]] int open(const std::string &title, int width, int height);
    [[nodiscard]] bool should_close(int id);
    void clear(int id, int red, int green, int blue);
    void set_pixel(int id, int x, int y, int red, int green, int blue);
    void fill_rect(int id, int x, int y, int width, int height, int red, int green, int blue);
    void draw_line(int id, int x1, int y1, int x2, int y2, int red, int green, int blue);
    void present(int id);
    void close(int id);

}
