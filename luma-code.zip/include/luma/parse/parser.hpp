#pragma once

#include <cstddef>
#include <vector>

#include "luma/ast/ast.hpp"
#include "luma/lex/token.hpp"

namespace luma
{

    // Recursive-descent parser for the Python-like, indentation-aware syntax.
    // Supports both Python 3.12+ features and Luma legacy aliases.
    class Parser
    {
    public:
        explicit Parser(std::vector<Token> tokens);

        [[nodiscard]] Program parse();

    private:
        // ── Statements ──────────────────────────────────────────────────
        [[nodiscard]] StmtPtr statement();
        [[nodiscard]] StmtPtr assignment_or_expr();
        [[nodiscard]] StmtPtr if_statement();
        [[nodiscard]] StmtPtr while_statement();
        [[nodiscard]] StmtPtr for_statement();
        [[nodiscard]] StmtPtr def_statement();
        [[nodiscard]] StmtPtr class_statement();
        [[nodiscard]] StmtPtr return_statement();
        [[nodiscard]] StmtPtr import_statement();
        [[nodiscard]] StmtPtr try_statement();
        [[nodiscard]] StmtPtr with_statement();
        [[nodiscard]] StmtPtr raise_statement();
        [[nodiscard]] StmtPtr global_statement();
        [[nodiscard]] StmtPtr del_statement();
        [[nodiscard]] StmtPtr print_statement();
        [[nodiscard]] StmtPtr expression_statement();

        [[nodiscard]] StmtList block();
        [[nodiscard]] StmtList suite(const char *what);

        // ── Expressions ─────────────────────────────────────────────────
        [[nodiscard]] ExprPtr expression();
        [[nodiscard]] ExprPtr lambda_expression();
        [[nodiscard]] ExprPtr ternary_expression();
        [[nodiscard]] ExprPtr walrus_expression();
        [[nodiscard]] ExprPtr or_expression();
        [[nodiscard]] ExprPtr and_expression();
        [[nodiscard]] ExprPtr not_expression();
        [[nodiscard]] ExprPtr comparison();
        [[nodiscard]] ExprPtr bitwise_or();
        [[nodiscard]] ExprPtr bitwise_xor();
        [[nodiscard]] ExprPtr bitwise_and();
        [[nodiscard]] ExprPtr shift_expression();
        [[nodiscard]] ExprPtr term();
        [[nodiscard]] ExprPtr factor();
        [[nodiscard]] ExprPtr power();
        [[nodiscard]] ExprPtr unary();
        [[nodiscard]] ExprPtr postfix();
        [[nodiscard]] ExprPtr primary();

        // ── Helpers ─────────────────────────────────────────────────────
        void skip_newlines();
        void expect_newline(const char *what);
        [[nodiscard]] bool match(TokenKind kind);
        [[nodiscard]] bool check(TokenKind kind) const;
        [[nodiscard]] const Token &advance();
        [[nodiscard]] const Token &peek() const;
        [[nodiscard]] const Token &previous() const;
        [[nodiscard]] const Token &consume(TokenKind kind, const std::string &message);

        [[nodiscard]] std::vector<std::string> parse_parameter_list();
        [[nodiscard]] std::vector<ExprPtr> parse_argument_list();

        std::vector<Token> tokens_;
        std::size_t current_{0};
        bool last_terminator_was_newline_{true};
    };

}
