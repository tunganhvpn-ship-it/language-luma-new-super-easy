#pragma once

#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "luma/core/source.hpp"
#include "luma/lex/token.hpp"
#include "luma/runtime/value.hpp"

namespace luma
{

    // ── Expressions ──────────────────────────────────────────────────────

    class Expr
    {
    public:
        explicit Expr(SourceLocation source_location) : location(source_location) {}
        virtual ~Expr() = default;

        SourceLocation location;
    };

    using ExprPtr = std::unique_ptr<Expr>;

    class LiteralExpr final : public Expr
    {
    public:
        LiteralExpr(SourceLocation source_location, Value initial_value)
            : Expr(source_location), value(std::move(initial_value)) {}

        Value value;
    };

    class NameExpr final : public Expr
    {
    public:
        NameExpr(SourceLocation source_location, std::string initial_name)
            : Expr(source_location), name(std::move(initial_name)) {}

        std::string name;
    };

    class CallExpr final : public Expr
    {
    public:
        CallExpr(SourceLocation source_location, ExprPtr callee_expr, std::vector<ExprPtr> call_arguments)
            : Expr(source_location), callee(std::move(callee_expr)), arguments(std::move(call_arguments)) {}

        // Legacy: name-based call (for stdlib functions)
        CallExpr(SourceLocation source_location, std::string callee_name, std::vector<ExprPtr> call_arguments)
            : Expr(source_location), callee(std::make_unique<NameExpr>(source_location, std::move(callee_name))),
              arguments(std::move(call_arguments)) {}

        ExprPtr callee;
        std::vector<ExprPtr> arguments;
    };

    class ListExpr final : public Expr
    {
    public:
        ListExpr(SourceLocation source_location, std::vector<ExprPtr> list_items)
            : Expr(source_location), items(std::move(list_items)) {}

        std::vector<ExprPtr> items;
    };

    class DictExpr final : public Expr
    {
    public:
        DictExpr(SourceLocation source_location, std::vector<ExprPtr> dict_keys, std::vector<ExprPtr> dict_values)
            : Expr(source_location), keys(std::move(dict_keys)), values(std::move(dict_values)) {}

        std::vector<ExprPtr> keys;
        std::vector<ExprPtr> values;
    };

    class SetExpr final : public Expr
    {
    public:
        SetExpr(SourceLocation source_location, std::vector<ExprPtr> set_items)
            : Expr(source_location), items(std::move(set_items)) {}

        std::vector<ExprPtr> items;
    };

    class TupleExpr final : public Expr
    {
    public:
        TupleExpr(SourceLocation source_location, std::vector<ExprPtr> tuple_items)
            : Expr(source_location), items(std::move(tuple_items)) {}

        std::vector<ExprPtr> items;
    };

    class IndexExpr final : public Expr
    {
    public:
        IndexExpr(SourceLocation source_location, ExprPtr index_base, ExprPtr index_value)
            : Expr(source_location), base(std::move(index_base)), index(std::move(index_value)) {}

        ExprPtr base;
        ExprPtr index;
    };

    class DotExpr final : public Expr
    {
    public:
        DotExpr(SourceLocation source_location, ExprPtr object_expr, std::string attribute_name)
            : Expr(source_location), object(std::move(object_expr)), attribute(std::move(attribute_name)) {}

        ExprPtr object;
        std::string attribute;
    };

    class UnaryExpr final : public Expr
    {
    public:
        UnaryExpr(SourceLocation source_location, TokenKind operator_kind, ExprPtr operand)
            : Expr(source_location), operation(operator_kind), right(std::move(operand)) {}

        TokenKind operation;
        ExprPtr right;
    };

    class BinaryExpr final : public Expr
    {
    public:
        BinaryExpr(SourceLocation source_location, ExprPtr left_operand, TokenKind operator_kind, ExprPtr right_operand)
            : Expr(source_location), left(std::move(left_operand)), operation(operator_kind), right(std::move(right_operand)) {}

        ExprPtr left;
        TokenKind operation;
        ExprPtr right;
    };

    class TernaryExpr final : public Expr
    {
    public:
        TernaryExpr(SourceLocation source_location, ExprPtr condition_expr,
                    ExprPtr true_value, ExprPtr false_value)
            : Expr(source_location), condition(std::move(condition_expr)),
              then_value(std::move(true_value)), else_value(std::move(false_value)) {}

        ExprPtr condition;
        ExprPtr then_value;
        ExprPtr else_value;
    };

    class LambdaExpr final : public Expr
    {
    public:
        LambdaExpr(SourceLocation source_location, std::vector<std::string> parameter_names,
                   ExprPtr body_expr)
            : Expr(source_location), parameters(std::move(parameter_names)),
              body(std::move(body_expr)) {}

        std::vector<std::string> parameters;
        ExprPtr body;
    };

    class FStringExpr final : public Expr
    {
    public:
        FStringExpr(SourceLocation source_location, std::vector<ExprPtr> parts)
            : Expr(source_location), segments(std::move(parts)) {}

        // Each segment is either a LiteralExpr (text) or an Expr (interpolation)
        std::vector<ExprPtr> segments;
    };

    class ListCompExpr final : public Expr
    {
    public:
        ListCompExpr(SourceLocation source_location, ExprPtr element_expr,
                     std::string variable_name, ExprPtr iterable_expr,
                     ExprPtr condition_expr = nullptr)
            : Expr(source_location), element(std::move(element_expr)),
              variable(std::move(variable_name)), iterable(std::move(iterable_expr)),
              condition(std::move(condition_expr)) {}

        ExprPtr element;
        std::string variable;
        ExprPtr iterable;
        ExprPtr condition;  // optional if-filter
    };

    // `x++` or `x--` (postfix increment/decrement)
    class IncDecExpr final : public Expr
    {
    public:
        IncDecExpr(SourceLocation source_location, std::string variable_name, bool is_increment)
            : Expr(source_location), name(std::move(variable_name)), increment(is_increment) {}

        std::string name;
        bool increment;  // true = ++, false = --
    };

    // ── Statements ───────────────────────────────────────────────────────

    class Stmt
    {
    public:
        explicit Stmt(SourceLocation source_location) : location(source_location) {}
        virtual ~Stmt() = default;

        SourceLocation location;
    };

    using StmtPtr = std::unique_ptr<Stmt>;
    using StmtList = std::vector<StmtPtr>;

    // `x = value` -- simple assignment (Python-style, no `let`)
    class AssignStmt final : public Stmt
    {
    public:
        AssignStmt(SourceLocation source_location, std::string variable_name, ExprPtr next_value)
            : Stmt(source_location), name(std::move(variable_name)), value(std::move(next_value)) {}

        std::string name;
        ExprPtr value;
    };

    // `x += 1`, `x -= 2`, etc. (augmented assignment)
    class AugAssignStmt final : public Stmt
    {
    public:
        AugAssignStmt(SourceLocation source_location, std::string variable_name,
                      TokenKind operator_kind, ExprPtr right_value)
            : Stmt(source_location), name(std::move(variable_name)),
              operation(operator_kind), value(std::move(right_value)) {}

        std::string name;
        TokenKind operation;
        ExprPtr value;
    };

    // `list[index] = value` -- writes into an element of a list.
    class IndexAssignStmt final : public Stmt
    {
    public:
        IndexAssignStmt(SourceLocation source_location, ExprPtr assigned_base, ExprPtr assigned_index, ExprPtr next_value)
            : Stmt(source_location), base(std::move(assigned_base)), index(std::move(assigned_index)),
              value(std::move(next_value)) {}

        ExprPtr base;
        ExprPtr index;
        ExprPtr value;
    };

    // `object.attr = value` -- attribute assignment
    class DotAssignStmt final : public Stmt
    {
    public:
        DotAssignStmt(SourceLocation source_location, ExprPtr assigned_object,
                      std::string attribute_name, ExprPtr next_value)
            : Stmt(source_location), object(std::move(assigned_object)),
              attribute(std::move(attribute_name)), value(std::move(next_value)) {}

        ExprPtr object;
        std::string attribute;
        ExprPtr value;
    };

    class BreakStmt final : public Stmt
    {
    public:
        explicit BreakStmt(SourceLocation source_location) : Stmt(source_location) {}
    };

    class ContinueStmt final : public Stmt
    {
    public:
        explicit ContinueStmt(SourceLocation source_location) : Stmt(source_location) {}
    };

    // `pass` -- does nothing; lets a block stay empty, like in Python.
    class PassStmt final : public Stmt
    {
    public:
        explicit PassStmt(SourceLocation source_location) : Stmt(source_location) {}
    };

    // `import utils` or `from utils import func` -- pulls another Luma file
    class ImportStmt final : public Stmt
    {
    public:
        ImportStmt(SourceLocation source_location, std::string module_name)
            : Stmt(source_location), module(std::move(module_name)) {}

        std::string module;
    };

    // `from module import name1, name2`
    class FromImportStmt final : public Stmt
    {
    public:
        FromImportStmt(SourceLocation source_location, std::string module_name,
                       std::vector<std::string> imported_names)
            : Stmt(source_location), module(std::move(module_name)),
              names(std::move(imported_names)) {}

        std::string module;
        std::vector<std::string> names;
    };

    // `print(...)` or legacy `show ...`
    class PrintStmt final : public Stmt
    {
    public:
        PrintStmt(SourceLocation source_location, ExprPtr displayed_value)
            : Stmt(source_location), value(std::move(displayed_value)) {}

        ExprPtr value;
    };

    // A bare expression used as a statement (e.g. calling `push(list, 1)` on
    // its own line): evaluated for its side effects, result discarded.
    class ExprStmt final : public Stmt
    {
    public:
        ExprStmt(SourceLocation source_location, ExprPtr evaluated_value)
            : Stmt(source_location), value(std::move(evaluated_value)) {}

        ExprPtr value;
    };

    // `def name(params):` -- function definition (Python-style)
    class FuncDefStmt final : public Stmt
    {
    public:
        FuncDefStmt(SourceLocation source_location, std::string function_name,
                    std::vector<std::string> parameter_names, StmtList function_body,
                    std::vector<ExprPtr> decorators = {})
            : Stmt(source_location), name(std::move(function_name)),
              parameters(std::move(parameter_names)), body(std::move(function_body)),
              decorator_list(std::move(decorators)) {}

        std::string name;
        std::vector<std::string> parameters;
        StmtList body;
        std::vector<ExprPtr> decorator_list;
    };

    // `return [value]`
    class ReturnStmt final : public Stmt
    {
    public:
        ReturnStmt(SourceLocation source_location, ExprPtr returned_value)
            : Stmt(source_location), value(std::move(returned_value)) {}

        bool has_value() const noexcept { return value != nullptr; }
        ExprPtr value;
    };

    // `for item in iterable:` -- iteration over a list/iterable
    class ForStmt final : public Stmt
    {
    public:
        ForStmt(SourceLocation source_location, std::string variable_name, ExprPtr sequence, StmtList loop_body)
            : Stmt(source_location), name(std::move(variable_name)), iterable(std::move(sequence)),
              body(std::move(loop_body)) {}

        std::string name;
        ExprPtr iterable;
        StmtList body;
    };

    // `while condition:` -- while loop
    class WhileStmt final : public Stmt
    {
    public:
        WhileStmt(SourceLocation source_location, ExprPtr loop_condition, StmtList loop_body)
            : Stmt(source_location), condition(std::move(loop_condition)), body(std::move(loop_body)) {}

        ExprPtr condition;
        StmtList body;
    };

    // `if ... elif ... else:` -- conditional (Python-style)
    class IfStmt final : public Stmt
    {
    public:
        IfStmt(SourceLocation source_location, ExprPtr condition_expr,
               StmtList then_branch, StmtList else_branch = {})
            : Stmt(source_location), condition(std::move(condition_expr)),
              then_branch(std::move(then_branch)),
              else_branch(std::move(else_branch)) {}

        ExprPtr condition;
        StmtList then_branch;
        StmtList else_branch;
    };

    // `class Name:` or `class Name(base):` -- class definition
    class ClassDefStmt final : public Stmt
    {
    public:
        ClassDefStmt(SourceLocation source_location, std::string class_name,
                     std::vector<ExprPtr> base_classes, StmtList class_body,
                     std::vector<ExprPtr> decorators = {})
            : Stmt(source_location), name(std::move(class_name)),
              bases(std::move(base_classes)), body(std::move(class_body)),
              decorator_list(std::move(decorators)) {}

        std::string name;
        std::vector<ExprPtr> bases;
        StmtList body;
        std::vector<ExprPtr> decorator_list;
    };

    // `try: ... except [ErrorType] [as e]: ... finally: ...`
    class TryStmt final : public Stmt
    {
    public:
        struct ExceptHandler
        {
            ExprPtr type;           // exception type (can be nullptr for bare except)
            std::string variable;   // "as" variable name (can be empty)
            StmtList body;
        };

        TryStmt(SourceLocation source_location, StmtList try_body,
                std::vector<ExceptHandler> handlers, StmtList finally_body = {})
            : Stmt(source_location), body(std::move(try_body)),
              handlers(std::move(handlers)), finally_body(std::move(finally_body)) {}

        StmtList body;
        std::vector<ExceptHandler> handlers;
        StmtList finally_body;
    };

    // `with expr as name: ...`
    class WithStmt final : public Stmt
    {
    public:
        WithStmt(SourceLocation source_location, ExprPtr context_expr,
                 std::string variable_name, StmtList with_body)
            : Stmt(source_location), context(std::move(context_expr)),
              variable(std::move(variable_name)), body(std::move(with_body)) {}

        ExprPtr context;
        std::string variable;
        StmtList body;
    };

    // `raise ExceptionType(args)`
    class RaiseStmt final : public Stmt
    {
    public:
        RaiseStmt(SourceLocation source_location, ExprPtr exception_expr)
            : Stmt(source_location), exception(std::move(exception_expr)) {}

        ExprPtr exception;
    };

    // `global x` or `nonlocal x`
    class GlobalStmt final : public Stmt
    {
    public:
        GlobalStmt(SourceLocation source_location, std::string variable_name, bool is_nonlocal)
            : Stmt(source_location), name(std::move(variable_name)), nonlocal(is_nonlocal) {}

        std::string name;
        bool nonlocal;
    };

    // `del x` or `del x[i]`
    class DelStmt final : public Stmt
    {
    public:
        DelStmt(SourceLocation source_location, ExprPtr target_expr)
            : Stmt(source_location), target(std::move(target_expr)) {}

        ExprPtr target;
    };

    // `@decorator` before a function or class
    class DecoratorStmt final : public Stmt
    {
    public:
        DecoratorStmt(SourceLocation source_location, ExprPtr decorator_expr, StmtPtr decorated)
            : Stmt(source_location), decorator(std::move(decorator_expr)),
              statement(std::move(decorated)) {}

        ExprPtr decorator;
        StmtPtr statement;
    };

    // ── Program ──────────────────────────────────────────────────────────

    struct Program
    {
        StmtList statements;
    };

}
