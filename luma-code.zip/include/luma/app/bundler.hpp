#pragma once

// Bytecode bundler for Luma v0.4 — Self-extracting executable approach.
//
// Architecture:
//   1. Pre-compile a VM stub (luma_vm.exe) that reads bytecode from itself
//   2. `luma build` compiles source to bytecode, then appends it to the VM stub
//   3. The resulting .exe is fully self-contained — no C++ compiler needed!
//
// Binary format (appended after PE):
//   [4 bytes: magic "LUMA"]
//   [4 bytes: bytecode size (little-endian)]
//   [N bytes: bytecode data]

#include <filesystem>
#include <string>

#include "luma/bytecode/chunk.hpp"

namespace luma::bundler
{

    // Serializes a Chunk into a compact binary format.
    [[nodiscard]] std::string serialize_chunk(const Chunk &chunk);

    // Bundles a pre-compiled VM stub with serialized bytecode into a
    // self-contained executable. Returns true on success.
    //
    // The output .exe can run on any Windows machine without needing
    // g++ or any other compiler installed.
    bool bundle_executable(const Chunk &chunk, const std::string &output_path,
                           const std::filesystem::path &exe_dir);

}
