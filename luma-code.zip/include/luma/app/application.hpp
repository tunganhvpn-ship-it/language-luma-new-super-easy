#pragma once

#include <string_view>
#include <vector>

namespace luma
{

    class Application
    {
    public:
        [[nodiscard]] int run(const std::vector<std::string_view> &arguments) const;
    };

}