#pragma once

#include <string_view>

namespace luma
{

    inline constexpr std::string_view version = "0.6.0";

}
