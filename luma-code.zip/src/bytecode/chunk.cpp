#include "luma/bytecode/chunk.hpp"

#include <utility>

namespace luma
{

    std::size_t Chunk::add_constant(Value value)
    {
        constants_.push_back(std::move(value));
        return constants_.size() - 1;
    }

    std::size_t Chunk::add_name(std::string name)
    {
        names_.push_back(std::move(name));
        return names_.size() - 1;
    }

    std::size_t Chunk::emit(OpCode opcode, std::size_t operand_a, std::size_t operand_b, SourceLocation location)
    {
        instructions_.push_back({opcode, operand_a, operand_b, location});
        return instructions_.size() - 1;
    }

    void Chunk::patch(std::size_t instruction, std::size_t operand_a)
    {
        instructions_.at(instruction).operand_a = operand_a;
    }

    void Chunk::patch_b(std::size_t instruction, std::size_t operand_b)
    {
        instructions_.at(instruction).operand_b = operand_b;
    }

    const std::vector<Value> &Chunk::constants() const noexcept { return constants_; }
    const std::vector<std::string> &Chunk::names() const noexcept { return names_; }
    const std::vector<Instruction> &Chunk::instructions() const noexcept { return instructions_; }

    std::size_t Chunk::add_function(std::vector<std::string> param_names, Chunk body)
    {
        auto info = std::make_shared<FunctionInfo>();
        info->param_names = std::move(param_names);
        info->body = std::move(body);
        functions_.push_back(std::move(info));
        return functions_.size() - 1;
    }

    const FunctionInfo &Chunk::function(std::size_t index) const
    {
        return *functions_.at(index);
    }

    std::size_t Chunk::function_count() const noexcept
    {
        return functions_.size();
    }

    const std::vector<std::shared_ptr<FunctionInfo>> &Chunk::functions() const noexcept
    {
        return functions_;
    }

}