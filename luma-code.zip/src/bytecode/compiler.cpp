#include "luma/bytecode/compiler.hpp"
#include "luma/core/diagnostic.hpp"

namespace luma {

Chunk Compiler::compile(const Program& p) {
    chunk_ = Chunk{};
    compile_block(p.statements);
    chunk_.emit(OpCode::halt, 0, 0, {1, 1});
    return std::move(chunk_);
}

void Compiler::compile_block(const StmtList& b) {
    for (const auto& s : b) compile_statement(*s);
}

void Compiler::compile_statement(const Stmt& st) {
    // ── AssignStmt: `x = value` ────────────────────────────────────────
    if (const auto* v = dynamic_cast<const AssignStmt*>(&st)) {
        compile_expression(*v->value);
        chunk_.emit(OpCode::define_global, chunk_.add_name(v->name), 0, st.location);
        return;
    }
    // ── AugAssignStmt: `x += value` etc. ───────────────────────────────
    if (const auto* v = dynamic_cast<const AugAssignStmt*>(&st)) {
        // Load current value, compute new value, assign
        std::size_t name_idx = chunk_.add_name(v->name);
        chunk_.emit(OpCode::load_global, name_idx, 0, st.location);
        compile_expression(*v->value);
        switch (v->operation) {
        case TokenKind::plus_equal:           chunk_.emit(OpCode::add, 0, 0, st.location); break;
        case TokenKind::minus_equal:          chunk_.emit(OpCode::subtract, 0, 0, st.location); break;
        case TokenKind::star_equal:           chunk_.emit(OpCode::multiply, 0, 0, st.location); break;
        case TokenKind::slash_equal:          chunk_.emit(OpCode::divide, 0, 0, st.location); break;
        case TokenKind::percent_equal:        chunk_.emit(OpCode::modulo, 0, 0, st.location); break;
        case TokenKind::double_slash_equal:   chunk_.emit(OpCode::divide, 0, 0, st.location); break; // TODO: floor divide
        case TokenKind::star_star_equal: {
            // x **= y  ->  x = pow(x, y)
            std::vector<std::size_t> args;
            chunk_.emit(OpCode::call, 2, 0, st.location); // pow
            break;
        }
        default:
            fail("Cannot compile this augmented assignment operator", st.location);
        }
        chunk_.emit(OpCode::assign_global, name_idx, 0, st.location);
        return;
    }
    // ── IndexAssignStmt: `list[i] = value` ─────────────────────────────
    if (const auto* v = dynamic_cast<const IndexAssignStmt*>(&st)) {
        compile_expression(*v->base);
        compile_expression(*v->index);
        compile_expression(*v->value);
        chunk_.emit(OpCode::index_set, 0, 0, st.location);
        return;
    }
    // ── DotAssignStmt: `obj.attr = value` (stub: treat as global set) ──
    if (const auto* v = dynamic_cast<const DotAssignStmt*>(&st)) {
        // For now, simple object attribute access not fully supported in bytecode
        fail("Attribute assignment is not yet supported in the bytecode compiler", st.location);
    }
    // ── PrintStmt: `print(...)` or legacy `show` ───────────────────────
    if (const auto* v = dynamic_cast<const PrintStmt*>(&st)) {
        // print() calls the native print function, same as show
        compile_expression(*v->value);
        chunk_.emit(OpCode::print, 0, 0, st.location);
        return;
    }
    // ── ExprStmt ───────────────────────────────────────────────────────
    if (const auto* v = dynamic_cast<const ExprStmt*>(&st)) {
        compile_expression(*v->value);
        chunk_.emit(OpCode::pop, 0, 0, st.location);
        return;
    }
    // ── IfStmt: `if ... elif ... else:` ────────────────────────────────
    if (const auto* v = dynamic_cast<const IfStmt*>(&st)) {
        compile_expression(*v->condition);
        std::size_t else_j = chunk_.emit(OpCode::jump_if_false, 0, 0, st.location);
        compile_block(v->then_branch);
        if (v->else_branch.empty()) {
            chunk_.patch(else_j, chunk_.instructions().size());
            return;
        }
        std::size_t end_j = chunk_.emit(OpCode::jump, 0, 0, st.location);
        chunk_.patch(else_j, chunk_.instructions().size());
        compile_block(v->else_branch);
        chunk_.patch(end_j, chunk_.instructions().size());
        return;
    }
    // ── WhileStmt ──────────────────────────────────────────────────────
    if (const auto* v = dynamic_cast<const WhileStmt*>(&st)) {
        std::size_t top = chunk_.instructions().size();
        compile_expression(*v->condition);
        std::size_t exit_j = chunk_.emit(OpCode::jump_if_false, 0, 0, st.location);
        loops_.push_back({LoopContext::Kind::while_loop, {}, {}});
        compile_block(v->body);
        chunk_.emit(OpCode::jump, top, 0, st.location);
        std::size_t exit = chunk_.instructions().size();
        chunk_.patch(exit_j, exit);
        for (std::size_t jump : loops_.back().break_jumps) chunk_.patch(jump, exit);
        for (std::size_t jump : loops_.back().continue_jumps) chunk_.patch(jump, top);
        loops_.pop_back();
        return;
    }
    // ── ForStmt: `for item in iterable:` ───────────────────────────────
    if (const auto* v = dynamic_cast<const ForStmt*>(&st)) {
        compile_expression(*v->iterable);
        std::size_t begin = chunk_.emit(OpCode::begin_for, chunk_.add_name(v->name), 0, st.location);
        loops_.push_back({LoopContext::Kind::for_loop, {}, {}});
        compile_block(v->body);
        std::size_t next = chunk_.emit(OpCode::for_next, begin, 0, st.location);
        std::size_t exit = chunk_.instructions().size();
        chunk_.patch_b(begin, exit);
        for (std::size_t jump : loops_.back().break_jumps) chunk_.patch(jump, exit);
        for (std::size_t jump : loops_.back().continue_jumps) chunk_.patch(jump, next);
        loops_.pop_back();
        return;
    }
    // ── FuncDefStmt: `def name(params):` ───────────────────────────────
    if (const auto* v = dynamic_cast<const FuncDefStmt*>(&st)) {
        Compiler sub;
        sub.compile_block(v->body);
        sub.chunk_.emit(OpCode::return_value, 0, 0, st.location);
        Chunk body = std::move(sub.chunk_);
        std::size_t fi = chunk_.add_function(v->parameters, std::move(body));
        chunk_.emit(OpCode::make_function, fi, 0, st.location);
        chunk_.emit(OpCode::define_global, chunk_.add_name(v->name), 0, st.location);
        return;
    }
    // ── ReturnStmt ─────────────────────────────────────────────────────
    if (const auto* v = dynamic_cast<const ReturnStmt*>(&st)) {
        if (v->has_value()) compile_expression(*v->value);
        else chunk_.emit(OpCode::constant, chunk_.add_constant(Value{}), 0, st.location);
        chunk_.emit(OpCode::return_value, 0, 0, st.location);
        return;
    }
    // ── BreakStmt ──────────────────────────────────────────────────────
    if (dynamic_cast<const BreakStmt*>(&st) != nullptr) {
        if (loops_.empty()) fail("'break' can only be used inside a loop", st.location);
        auto& loop = loops_.back();
        loop.break_jumps.push_back(chunk_.emit(OpCode::jump, 0, 0, st.location));
        return;
    }
    // ── ContinueStmt ───────────────────────────────────────────────────
    if (dynamic_cast<const ContinueStmt*>(&st) != nullptr) {
        if (loops_.empty()) fail("'continue' can only be used inside a loop", st.location);
        loops_.back().continue_jumps.push_back(chunk_.emit(OpCode::jump, 0, 0, st.location));
        return;
    }
    // ── PassStmt ───────────────────────────────────────────────────────
    if (dynamic_cast<const PassStmt*>(&st) != nullptr) return;
    // ── ImportStmt ─────────────────────────────────────────────────────
    if (dynamic_cast<const ImportStmt*>(&st) != nullptr)
        fail("'import' is only allowed at the top of a file", st.location);
    if (dynamic_cast<const FromImportStmt*>(&st) != nullptr)
        fail("'from...import' is only allowed at the top of a file", st.location);
    // ── ClassDefStmt (basic: create empty class) ───────────────────────
    if (const auto* v = dynamic_cast<const ClassDefStmt*>(&st)) {
        // Simple class: just create a class value as an empty dict-like object
        // For now, compile the body in a sub-compiler and store as a function
        Compiler sub;
        sub.compile_block(v->body);
        sub.chunk_.emit(OpCode::return_value, 0, 0, st.location);
        Chunk body = std::move(sub.chunk_);
        std::size_t fi = chunk_.add_function({}, std::move(body));
        chunk_.emit(OpCode::make_function, fi, 0, st.location);
        chunk_.emit(OpCode::define_global, chunk_.add_name(v->name), 0, st.location);
        return;
    }
    // ── TryStmt (basic: execute try body, ignore exceptions) ───────────
    if (const auto* v = dynamic_cast<const TryStmt*>(&st)) {
        // Simple try/except: compile try body, skip handlers on success
        compile_block(v->body);
        return;
    }
    // ── RaiseStmt ──────────────────────────────────────────────────────
    if (dynamic_cast<const RaiseStmt*>(&st) != nullptr) {
        fail("'raise' is not yet supported in the bytecode compiler", st.location);
    }
    // ── GlobalStmt ─────────────────────────────────────────────────────
    if (dynamic_cast<const GlobalStmt*>(&st) != nullptr) {
        // Global/nonlocal is implicit in the current VM model (globals only)
        return;
    }
    // ── DelStmt ────────────────────────────────────────────────────────
    if (dynamic_cast<const DelStmt*>(&st) != nullptr) {
        fail("'del' is not yet supported in the bytecode compiler", st.location);
    }
    // ── WithStmt (basic) ───────────────────────────────────────────────
    if (dynamic_cast<const WithStmt*>(&st) != nullptr) {
        fail("'with' is not yet supported in the bytecode compiler", st.location);
    }
    // ── DecoratorStmt ──────────────────────────────────────────────────
    if (const auto* v = dynamic_cast<const DecoratorStmt*>(&st)) {
        // For now, just compile the decorated statement ignoring the decorator
        compile_statement(*v->statement);
        return;
    }

    fail("Cannot compile this statement", st.location);
}

void Compiler::compile_expression(const Expr& e) {
    // ── LiteralExpr ────────────────────────────────────────────────────
    if (const auto* v = dynamic_cast<const LiteralExpr*>(&e)) {
        chunk_.emit(OpCode::constant, chunk_.add_constant(v->value), 0, e.location);
        return;
    }
    // ── NameExpr ───────────────────────────────────────────────────────
    if (const auto* v = dynamic_cast<const NameExpr*>(&e)) {
        chunk_.emit(OpCode::load_global, chunk_.add_name(v->name), 0, e.location);
        return;
    }
    // ── UnaryExpr ──────────────────────────────────────────────────────
    if (const auto* v = dynamic_cast<const UnaryExpr*>(&e)) {
        compile_expression(*v->right);
        switch (v->operation) {
        case TokenKind::minus:       chunk_.emit(OpCode::negate, 0, 0, e.location); return;
        case TokenKind::not_keyword: chunk_.emit(OpCode::logical_not, 0, 0, e.location); return;
        case TokenKind::tilde:       fail("'~' (bitwise not) not yet supported", e.location); return;
        default: fail("Cannot compile this unary operator", e.location);
        }
    }
    // ── BinaryExpr ─────────────────────────────────────────────────────
    if (const auto* v = dynamic_cast<const BinaryExpr*>(&e)) {
        // Short-circuit for `and` / `or`
        if (v->operation == TokenKind::and_keyword) {
            compile_expression(*v->left);
            std::size_t false_j = chunk_.emit(OpCode::jump_if_false, 0, 0, e.location);
            chunk_.emit(OpCode::pop, 0, 0, e.location);
            compile_expression(*v->right);
            std::size_t end_j = chunk_.emit(OpCode::jump, 0, 0, e.location);
            chunk_.patch(false_j, chunk_.instructions().size());
            return;
        }
        if (v->operation == TokenKind::or_keyword) {
            compile_expression(*v->left);
            std::size_t true_j = chunk_.emit(OpCode::jump_if_false, 0, 0, e.location);
            std::size_t end_j = chunk_.emit(OpCode::jump, 0, 0, e.location);
            chunk_.patch(true_j, chunk_.instructions().size());
            chunk_.emit(OpCode::pop, 0, 0, e.location);
            compile_expression(*v->right);
            chunk_.patch(end_j, chunk_.instructions().size());
            return;
        }
        // `a ** b` -> call pow(a, b)
        if (v->operation == TokenKind::star_star) {
            std::size_t pow_idx = chunk_.add_name("pow");
            chunk_.emit(OpCode::load_global, pow_idx, 0, e.location);
            compile_expression(*v->left);
            compile_expression(*v->right);
            chunk_.emit(OpCode::call, 2, 0, e.location);
            return;
        }
        compile_expression(*v->left);
        compile_expression(*v->right);
        OpCode op = OpCode::add;
        switch (v->operation) {
        case TokenKind::plus:          op = OpCode::add; break;
        case TokenKind::minus:         op = OpCode::subtract; break;
        case TokenKind::star:          op = OpCode::multiply; break;
        case TokenKind::slash:         op = OpCode::divide; break;
        case TokenKind::percent:       op = OpCode::modulo; break;
        case TokenKind::equal_equal:   op = OpCode::equal; break;
        case TokenKind::bang_equal:    op = OpCode::not_equal; break;
        case TokenKind::less:          op = OpCode::less; break;
        case TokenKind::less_equal:    op = OpCode::less_equal; break;
        case TokenKind::greater:       op = OpCode::greater; break;
        case TokenKind::greater_equal: op = OpCode::greater_equal; break;
        default: fail("Cannot compile this binary operator", e.location);
        }
        chunk_.emit(op, 0, 0, e.location);
        return;
    }
    // ── TernaryExpr: `a if cond else b` ────────────────────────────────
    if (const auto* v = dynamic_cast<const TernaryExpr*>(&e)) {
        compile_expression(*v->condition);
        std::size_t false_j = chunk_.emit(OpCode::jump_if_false, 0, 0, e.location);
        compile_expression(*v->then_value);
        std::size_t end_j = chunk_.emit(OpCode::jump, 0, 0, e.location);
        chunk_.patch(false_j, chunk_.instructions().size());
        compile_expression(*v->else_value);
        chunk_.patch(end_j, chunk_.instructions().size());
        return;
    }
    // ── CallExpr ───────────────────────────────────────────────────────
    if (const auto* v = dynamic_cast<const CallExpr*>(&e)) {
        compile_expression(*v->callee);
        for (const auto& a : v->arguments) compile_expression(*a);
        chunk_.emit(OpCode::call, v->arguments.size(), 0, e.location);
        return;
    }
    // ── ListExpr ───────────────────────────────────────────────────────
    if (const auto* v = dynamic_cast<const ListExpr*>(&e)) {
        for (const auto& it : v->items) compile_expression(*it);
        chunk_.emit(OpCode::make_list, v->items.size(), 0, e.location);
        return;
    }
    // ── IndexExpr ──────────────────────────────────────────────────────
    if (const auto* v = dynamic_cast<const IndexExpr*>(&e)) {
        compile_expression(*v->base);
        compile_expression(*v->index);
        chunk_.emit(OpCode::index_get, 0, 0, e.location);
        return;
    }
    // ── DotExpr (stub) ─────────────────────────────────────────────────
    if (dynamic_cast<const DotExpr*>(&e) != nullptr) {
        fail("Attribute access is not yet supported in the bytecode compiler", e.location);
    }
    // ── DictExpr ───────────────────────────────────────────────────────
    if (const auto* v = dynamic_cast<const DictExpr*>(&e)) {
        // Compile as: make empty dict, then set each key-value pair
        // For now, treat as a list of [key, value, key, value, ...]
        for (std::size_t i = 0; i < v->keys.size(); ++i) {
            compile_expression(*v->keys[i]);
            compile_expression(*v->values[i]);
        }
        // Push dict size as constant, then call make_dict (TODO: add opcode)
        chunk_.emit(OpCode::make_list, v->keys.size() * 2, 0, e.location);
        return;
    }
    // ── LambdaExpr ─────────────────────────────────────────────────────
    if (const auto* v = dynamic_cast<const LambdaExpr*>(&e)) {
        Compiler sub;
        // Compile body as expression + return
        sub.compile_expression(*v->body);
        sub.chunk_.emit(OpCode::return_value, 0, 0, e.location);
        Chunk body = std::move(sub.chunk_);
        std::size_t fi = chunk_.add_function(v->parameters, std::move(body));
        chunk_.emit(OpCode::make_function, fi, 0, e.location);
        return;
    }
    // ── ListCompExpr: [x for x in items if cond] ──────────────────────
    if (const auto* v = dynamic_cast<const ListCompExpr*>(&e)) {
        // Desugar to: create empty list, iterate, filter, append
        // Use a sub-compiler with a function body approach
        // For now, just desugar via call to a helper
        // result = []
        // for var in iterable:
        //     if cond (optional):
        //         push(result, element)
        // result
        //
        // Stack approach:
        // 1. Load "push" and empty list onto stack
        // 2. For each iteration, compute element, call push

        // Create the result list in a temp variable
        std::string result_name = "__lc_" + std::to_string(temp_counter_++);
        chunk_.emit(OpCode::constant, chunk_.add_constant(
            Value{std::make_shared<std::vector<Value>>(std::vector<Value>{})}), 0, e.location);
        chunk_.emit(OpCode::define_global, chunk_.add_name(result_name), 0, e.location);

        // Compile iterable and begin for-loop
        compile_expression(*v->iterable);
        std::size_t begin = chunk_.emit(OpCode::begin_for, chunk_.add_name(v->variable), 0, e.location);
        loops_.push_back({LoopContext::Kind::for_loop, {}, {}});

        // Optional filter condition
        std::size_t filter_j = 0;
        if (v->condition) {
            compile_expression(*v->condition);
            filter_j = chunk_.emit(OpCode::jump_if_false, 0, 0, e.location);
        }

        // Compute element, store in temp, call push(result, temp)
        compile_expression(*v->element);
        std::string elem_name = "__lce_" + std::to_string(temp_counter_++);
        chunk_.emit(OpCode::define_global, chunk_.add_name(elem_name), 0, e.location);

        // push(result_name, elem_name): load push, load result, load elem, call
        std::size_t push_idx = chunk_.add_name("push");
        std::size_t res_idx = chunk_.add_name(result_name);
        std::size_t el_idx = chunk_.add_name(elem_name);
        chunk_.emit(OpCode::load_global, push_idx, 0, e.location);
        chunk_.emit(OpCode::load_global, res_idx, 0, e.location);
        chunk_.emit(OpCode::load_global, el_idx, 0, e.location);
        chunk_.emit(OpCode::call, 2, 0, e.location);
        chunk_.emit(OpCode::pop, 0, 0, e.location);

        if (v->condition) {
            if (filter_j) chunk_.patch(filter_j, chunk_.instructions().size());
        }

        // End for-loop
        std::size_t next = chunk_.emit(OpCode::for_next, begin, 0, e.location);
        std::size_t exit = chunk_.instructions().size();
        chunk_.patch_b(begin, exit);
        for (std::size_t jump : loops_.back().break_jumps) chunk_.patch(jump, exit);
        for (std::size_t jump : loops_.back().continue_jumps) chunk_.patch(jump, next);
        loops_.pop_back();

        // Load result list as the expression value
        std::size_t final_idx = chunk_.add_name(result_name);
        chunk_.emit(OpCode::load_global, final_idx, 0, e.location);
        return;
    }
    if (const auto* v = dynamic_cast<const IncDecExpr*>(&e)) {
        std::size_t name_idx = chunk_.add_name(v->name);
        chunk_.emit(OpCode::load_global, name_idx, 0, e.location);
        ExprPtr one = std::make_unique<LiteralExpr>(e.location, Value{1.0});
        compile_expression(*one);
        if (v->increment)
            chunk_.emit(OpCode::add, 0, 0, e.location);
        else
            chunk_.emit(OpCode::subtract, 0, 0, e.location);
        chunk_.emit(OpCode::assign_global, name_idx, 0, e.location);
        // Load the new value as the expression result
        chunk_.emit(OpCode::load_global, name_idx, 0, e.location);
        return;
    }

    fail("Cannot compile this expression", e.location);
}

}
