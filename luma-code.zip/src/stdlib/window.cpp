#include "luma/stdlib/window.hpp"

#include <iostream>
#include <unordered_map>

#ifdef LUMA_HAVE_SDL2
#include <SDL.h>
#endif

namespace luma::stdlib::window
{
    namespace
    {

#ifdef LUMA_HAVE_SDL2

        struct WindowState
        {
            SDL_Window *window{nullptr};
            SDL_Renderer *renderer{nullptr};
            Uint32 sdl_window_id{0};
            bool closed{false};
        };

        std::unordered_map<int, WindowState> &windows()
        {
            static std::unordered_map<int, WindowState> instance;
            return instance;
        }

        bool ensure_sdl_ready()
        {
            static bool initialized = false;
            static bool succeeded = false;
            if (!initialized)
            {
                initialized = true;
                succeeded = SDL_Init(SDL_INIT_VIDEO) == 0;
                if (!succeeded)
                    std::cerr << "Luma: could not start SDL2 (" << SDL_GetError() << ")\n";
            }
            return succeeded;
        }

        WindowState *find(int id)
        {
            const auto it = windows().find(id);
            return it == windows().end() ? nullptr : &it->second;
        }

#else

        bool warn_once()
        {
            static bool warned = false;
            if (!warned)
            {
                warned = true;
                std::cerr << "Luma: this build has no SDL2, so window_* calls do nothing. "
                             "Install SDL2 development files and rebuild to enable real windows.\n";
            }
            return false;
        }

#endif

    }

    int open(const std::string &title, int width, int height)
    {
#ifdef LUMA_HAVE_SDL2
        if (!ensure_sdl_ready())
            return -1;
        SDL_Window *created_window = SDL_CreateWindow(title.c_str(), SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                                        width, height, SDL_WINDOW_SHOWN);
        if (created_window == nullptr)
        {
            std::cerr << "Luma: could not open window (" << SDL_GetError() << ")\n";
            return -1;
        }
        SDL_Renderer *renderer = SDL_CreateRenderer(created_window, -1, SDL_RENDERER_ACCELERATED);
        if (renderer == nullptr)
            renderer = SDL_CreateRenderer(created_window, -1, SDL_RENDERER_SOFTWARE);
        if (renderer == nullptr)
        {
            std::cerr << "Luma: could not create a renderer (" << SDL_GetError() << ")\n";
            SDL_DestroyWindow(created_window);
            return -1;
        }
        static int next_id = 1;
        const int id = next_id++;
        windows()[id] = WindowState{created_window, renderer, SDL_GetWindowID(created_window), false};
        return id;
#else
        static_cast<void>(title);
        static_cast<void>(width);
        static_cast<void>(height);
        warn_once();
        return -1;
#endif
    }

    bool should_close(int id)
    {
#ifdef LUMA_HAVE_SDL2
        auto *state = find(id);
        if (state == nullptr)
            return true;
        SDL_Event event;
        while (SDL_PollEvent(&event) != 0)
        {
            if (event.type == SDL_QUIT)
                state->closed = true;
            if (event.type == SDL_WINDOWEVENT && event.window.event == SDL_WINDOWEVENT_CLOSE &&
                event.window.windowID == state->sdl_window_id)
                state->closed = true;
        }
        return state->closed;
#else
        static_cast<void>(id);
        return true;
#endif
    }

    void clear(int id, int red, int green, int blue)
    {
#ifdef LUMA_HAVE_SDL2
        auto *state = find(id);
        if (state == nullptr)
            return;
        SDL_SetRenderDrawColor(state->renderer, static_cast<Uint8>(red), static_cast<Uint8>(green),
                                static_cast<Uint8>(blue), 255);
        SDL_RenderClear(state->renderer);
#else
        static_cast<void>(id);
        static_cast<void>(red);
        static_cast<void>(green);
        static_cast<void>(blue);
#endif
    }

    void set_pixel(int id, int x, int y, int red, int green, int blue)
    {
#ifdef LUMA_HAVE_SDL2
        auto *state = find(id);
        if (state == nullptr)
            return;
        SDL_SetRenderDrawColor(state->renderer, static_cast<Uint8>(red), static_cast<Uint8>(green),
                                static_cast<Uint8>(blue), 255);
        SDL_RenderDrawPoint(state->renderer, x, y);
#else
        static_cast<void>(id);
        static_cast<void>(x);
        static_cast<void>(y);
        static_cast<void>(red);
        static_cast<void>(green);
        static_cast<void>(blue);
#endif
    }

    void fill_rect(int id, int x, int y, int width, int height, int red, int green, int blue)
    {
#ifdef LUMA_HAVE_SDL2
        auto *state = find(id);
        if (state == nullptr)
            return;
        SDL_SetRenderDrawColor(state->renderer, static_cast<Uint8>(red), static_cast<Uint8>(green),
                                static_cast<Uint8>(blue), 255);
        const SDL_Rect rectangle{x, y, width, height};
        SDL_RenderFillRect(state->renderer, &rectangle);
#else
        static_cast<void>(id);
        static_cast<void>(x);
        static_cast<void>(y);
        static_cast<void>(width);
        static_cast<void>(height);
        static_cast<void>(red);
        static_cast<void>(green);
        static_cast<void>(blue);
#endif
    }

    void draw_line(int id, int x1, int y1, int x2, int y2, int red, int green, int blue)
    {
#ifdef LUMA_HAVE_SDL2
        auto *state = find(id);
        if (state == nullptr)
            return;
        SDL_SetRenderDrawColor(state->renderer, static_cast<Uint8>(red), static_cast<Uint8>(green),
                                static_cast<Uint8>(blue), 255);
        SDL_RenderDrawLine(state->renderer, x1, y1, x2, y2);
#else
        static_cast<void>(id);
        static_cast<void>(x1);
        static_cast<void>(y1);
        static_cast<void>(x2);
        static_cast<void>(y2);
        static_cast<void>(red);
        static_cast<void>(green);
        static_cast<void>(blue);
#endif
    }

    void present(int id)
    {
#ifdef LUMA_HAVE_SDL2
        auto *state = find(id);
        if (state == nullptr)
            return;
        SDL_RenderPresent(state->renderer);
#else
        static_cast<void>(id);
#endif
    }

    void close(int id)
    {
#ifdef LUMA_HAVE_SDL2
        auto *state = find(id);
        if (state == nullptr)
            return;
        SDL_DestroyRenderer(state->renderer);
        SDL_DestroyWindow(state->window);
        windows().erase(id);
#else
        static_cast<void>(id);
#endif
    }

}
