#include "luma/stdlib/registry.hpp"

namespace luma
{

    const std::vector<StandardLibraryModule> &standard_library_modules()
    {
        static const std::vector<StandardLibraryModule> modules{
            {"core", "Value and truthiness rules"},
            {"text", "Text conversion and composition"},
            {"math", "Numeric operations"},
            {"collections", "Future list and map capabilities"},
        };
        return modules;
    }

}