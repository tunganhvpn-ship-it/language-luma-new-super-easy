#include "luma/parse/parser.hpp"
#include <utility>
#include "luma/core/diagnostic.hpp"

namespace luma {

Parser::Parser(std::vector<Token> t) : tokens_(std::move(t)) {}

Program Parser::parse() {
    Program p;
    skip_newlines();
    while (!check(TokenKind::end)) {
        p.statements.push_back(statement());
        skip_newlines();
    }
    return p;
}

// ── Statement dispatch ────────────────────────────────────────────────

StmtPtr Parser::statement() {
    // Decorators: @expr before def or class
    if (check(TokenKind::at)) {
        advance(); // skip @
        ExprPtr decorator = expression();
        skip_newlines();
        StmtPtr decorated = statement();
        return std::make_unique<DecoratorStmt>(decorator->location, std::move(decorator), std::move(decorated));
    }

    if (check(TokenKind::if_keyword))      return if_statement();
    if (check(TokenKind::while_keyword))   return while_statement();
    if (check(TokenKind::for_keyword))     return for_statement();
    if (check(TokenKind::def_keyword))     return def_statement();
    if (check(TokenKind::class_keyword))   return class_statement();
    if (check(TokenKind::return_keyword))  return return_statement();
    if (check(TokenKind::import_keyword))  return import_statement();
    if (check(TokenKind::from_keyword))    return import_statement();
    if (check(TokenKind::try_keyword))     return try_statement();
    if (check(TokenKind::with_keyword))    return with_statement();
    if (check(TokenKind::raise_keyword))   return raise_statement();
    if (check(TokenKind::global_keyword) || check(TokenKind::nonlocal_keyword))
        return global_statement();
    if (check(TokenKind::del_keyword))     return del_statement();
    if (check(TokenKind::pass_keyword)) {
        Token k = advance();
        expect_newline("pass");
        return std::make_unique<PassStmt>(k.location);
    }
    if (check(TokenKind::break_keyword)) {
        Token k = advance();
        expect_newline("break");
        return std::make_unique<BreakStmt>(k.location);
    }
    if (check(TokenKind::continue_keyword)) {
        Token k = advance();
        expect_newline("continue");
        return std::make_unique<ContinueStmt>(k.location);
    }
    // `assert(expr)` and `assert(expr, "msg")` — built-in assert
    if (check(TokenKind::assert_keyword)) {
        Token k = advance(); // skip 'assert'
        consume(TokenKind::left_paren, "Need '(' after 'assert'");
        std::vector<ExprPtr> args;
        if (!check(TokenKind::right_paren)) {
            do { args.push_back(expression()); } while (match(TokenKind::comma));
        }
        consume(TokenKind::right_paren, "Need ')' after assert arguments");
        expect_newline("assert");
        ExprPtr callee = std::make_unique<NameExpr>(k.location, "assert");
        return std::make_unique<ExprStmt>(k.location,
            std::make_unique<CallExpr>(k.location, std::move(callee), std::move(args)));
    }

    // ── Legacy Luma aliases ────────────────────────────────────────────
    // `show expr` -> print(expr)
    if (check(TokenKind::identifier) && peek().lexeme == "show")
        return print_statement();
    // `let x = expr` -> x = expr
    if (check(TokenKind::identifier) && peek().lexeme == "let")
        return assignment_or_expr();
    // `repeat N:` -> sugar for `for _ in range(N):`  (handled in assignment_or_expr)
    if (check(TokenKind::identifier) && peek().lexeme == "repeat")
        return assignment_or_expr();
    // `until cond:` -> `while not cond:`
    if (check(TokenKind::identifier) && peek().lexeme == "until")
        return while_statement();
    // `forever:` -> `while True:`
    if (check(TokenKind::identifier) && peek().lexeme == "forever")
        return while_statement();
    // `when cond:` -> `if cond:`
    if (check(TokenKind::identifier) && peek().lexeme == "when")
        return if_statement();
    // `otherwise:` -> `else:` (should not appear at statement level normally)
    if (check(TokenKind::identifier) && (peek().lexeme == "otherwise" || peek().lexeme == "else")) {
        fail("'else' / 'otherwise' must follow an 'if' or 'elif' block", peek().location);
    }
    // `func name():` -> `def name():`
    if (check(TokenKind::identifier) && peek().lexeme == "func")
        return def_statement();

    // ── Plain assignment: identifier = expr or identifier += expr ───────
    if (check(TokenKind::identifier) && current_ + 1 < tokens_.size()) {
        const TokenKind next = tokens_[current_ + 1].kind;
        if (next == TokenKind::equal || next == TokenKind::plus_equal ||
            next == TokenKind::minus_equal || next == TokenKind::star_equal ||
            next == TokenKind::slash_equal || next == TokenKind::percent_equal ||
            next == TokenKind::double_slash_equal || next == TokenKind::star_star_equal ||
            next == TokenKind::at_equal) {
            return assignment_or_expr();
        }
    }

    return expression_statement();
}

// ── Assignment / Expression statement ─────────────────────────────────

StmtPtr Parser::assignment_or_expr() {
    // Legacy: `let x = expr`
    if (check(TokenKind::identifier) && peek().lexeme == "let") {
        Token k = advance(); // skip 'let'
        const Token& n = consume(TokenKind::identifier, "Need name after 'let'");
        consume(TokenKind::equal, "Need '=' after name");
        ExprPtr v = expression();
        expect_newline("assignment");
        return std::make_unique<AssignStmt>(k.location, n.lexeme, std::move(v));
    }

    // Legacy: `repeat N:` -> desugar to `for _ in range(N):`
    if (check(TokenKind::identifier) && peek().lexeme == "repeat") {
        Token k = advance(); // skip 'repeat'
        ExprPtr count = expression();
        consume(TokenKind::colon, "Need ':' after count");
        // Desugar: for _tmp in range(count):
        std::vector<ExprPtr> range_args;
        range_args.push_back(std::move(count));
        ExprPtr range_call = std::make_unique<CallExpr>(
            k.location, "range", std::move(range_args));
        return std::make_unique<ForStmt>(k.location, "_", std::move(range_call), suite("repeat"));
    }

    // Check if this is an assignment: `identifier = expr` or `identifier += expr` etc.
    if (check(TokenKind::identifier) && current_ + 1 < tokens_.size()) {
        const TokenKind next = tokens_[current_ + 1].kind;

        if (next == TokenKind::equal) {
            Token n = advance(); advance();
            ExprPtr value = expression();
            expect_newline("assignment");
            return std::make_unique<AssignStmt>(n.location, n.lexeme, std::move(value));
        }

        // Augmented assignment: x += 1, x -= 2, etc.
        if (next == TokenKind::plus_equal || next == TokenKind::minus_equal ||
            next == TokenKind::star_equal || next == TokenKind::slash_equal ||
            next == TokenKind::percent_equal || next == TokenKind::double_slash_equal ||
            next == TokenKind::star_star_equal || next == TokenKind::at_equal) {
            Token n = advance();
            Token op = advance();
            ExprPtr value = expression();
            expect_newline("augmented assignment");
            return std::make_unique<AugAssignStmt>(n.location, n.lexeme, op.kind, std::move(value));
        }
    }

    // Otherwise, it's an expression statement
    return expression_statement();
}

// ── if / elif / else ──────────────────────────────────────────────────

StmtPtr Parser::if_statement() {
    Token k = advance(); // skip 'if' or legacy 'when'
    ExprPtr condition = expression();
    consume(TokenKind::colon, "Need ':' after condition");
    StmtList then_branch = suite("if header");

    StmtList else_branch;
    if (check(TokenKind::elif_keyword)) {
        // elif -> nested IfStmt in else_branch
        else_branch.push_back(if_statement());
    } else if (match(TokenKind::else_keyword)) {
        consume(TokenKind::colon, "Need ':' after 'else'");
        else_branch = suite("else header");
    }

    return std::make_unique<IfStmt>(k.location, std::move(condition),
                                     std::move(then_branch), std::move(else_branch));
}

// ── while ─────────────────────────────────────────────────────────────

StmtPtr Parser::while_statement() {
    Token k = advance(); // skip 'while' (or legacy 'until', 'forever')

    // Legacy: `until cond:` -> while not cond
    if (k.lexeme == "until") {
        ExprPtr condition = expression();
        consume(TokenKind::colon, "Need ':' after condition");
        ExprPtr negated = std::make_unique<UnaryExpr>(k.location, TokenKind::not_keyword, std::move(condition));
        return std::make_unique<WhileStmt>(k.location, std::move(negated), suite("while header"));
    }

    // Legacy: `forever:` -> while True
    if (k.lexeme == "forever") {
        consume(TokenKind::colon, "Need ':' after 'forever'");
        ExprPtr always_true = std::make_unique<LiteralExpr>(k.location, Value{true});
        return std::make_unique<WhileStmt>(k.location, std::move(always_true), suite("while header"));
    }

    // Normal: `while condition:`
    ExprPtr condition = expression();
    consume(TokenKind::colon, "Need ':' after condition");
    return std::make_unique<WhileStmt>(k.location, std::move(condition), suite("while header"));
}

// ── for ... in ... : (with optional `to` for counting) ────────────────

StmtPtr Parser::for_statement() {
    Token k = advance(); // skip 'for'
    const Token& n = consume(TokenKind::identifier, "Need variable name after 'for'");
    consume(TokenKind::in_keyword, "Need 'in' after variable name");
    ExprPtr iterable = expression();

    // `for i in 1 to 10 [step 2]:` -- counting loop (Luma legacy, inclusive)
    // Desugar to: for i in range(start, stop+1, step)
    if (check(TokenKind::identifier) && peek().lexeme == "to") {
        advance(); // skip 'to'
        ExprPtr stop = expression();
        ExprPtr step;
        if (check(TokenKind::identifier) && peek().lexeme == "step") {
            advance(); // skip 'step'
            step = expression();
        } else {
            step = std::make_unique<LiteralExpr>(k.location, Value{1.0});
        }
        consume(TokenKind::colon, "Need ':' after range");
        // Desugar: for i in range_inclusive(start, stop, step)
        std::vector<ExprPtr> range_args;
        range_args.push_back(std::move(iterable));
        range_args.push_back(std::move(stop));
        range_args.push_back(std::move(step));
        ExprPtr range_call = std::make_unique<CallExpr>(k.location, "range_inclusive", std::move(range_args));
        return std::make_unique<ForStmt>(k.location, n.lexeme, std::move(range_call), suite("for header"));
    }

    consume(TokenKind::colon, "Need ':' after iterable");
    return std::make_unique<ForStmt>(k.location, n.lexeme, std::move(iterable), suite("for header"));
}

// ── def name(params): ─────────────────────────────────────────────────

StmtPtr Parser::def_statement() {
    Token k = advance(); // skip 'def' or legacy 'func'
    const Token& n = consume(TokenKind::identifier, "Need name after 'def'");
    consume(TokenKind::left_paren, "Need '(' after name");
    auto params = parse_parameter_list();
    consume(TokenKind::right_paren, "Need ')' after parameters");
    consume(TokenKind::colon, "Need ':' before body");
    return std::make_unique<FuncDefStmt>(k.location, n.lexeme, std::move(params), suite("def header"));
}

// ── class Name[(bases)]: ─────────────────────────────────────────────

StmtPtr Parser::class_statement() {
    Token k = advance(); // skip 'class'
    const Token& n = consume(TokenKind::identifier, "Need class name");

    std::vector<ExprPtr> bases;
    if (match(TokenKind::left_paren)) {
        if (!check(TokenKind::right_paren)) {
            do { bases.push_back(expression()); } while (match(TokenKind::comma));
        }
        consume(TokenKind::right_paren, "Need ')' after base classes");
    }

    consume(TokenKind::colon, "Need ':' after class header");
    return std::make_unique<ClassDefStmt>(k.location, n.lexeme, std::move(bases), suite("class header"));
}

// ── return [value] ────────────────────────────────────────────────────

StmtPtr Parser::return_statement() {
    Token k = advance();
    if (check(TokenKind::newline) || check(TokenKind::dedent) || check(TokenKind::end) ||
        check(TokenKind::semicolon)) {
        expect_newline("return");
        return std::make_unique<ReturnStmt>(k.location, ExprPtr{nullptr});
    }
    ExprPtr v = expression();
    expect_newline("return");
    return std::make_unique<ReturnStmt>(k.location, std::move(v));
}

// ── import / from ... import ... ──────────────────────────────────────

StmtPtr Parser::import_statement() {
    Token k = advance();

    // `from module import name1, name2`
    if (k.kind == TokenKind::from_keyword) {
        std::string module = consume(TokenKind::identifier, "Need module name after 'from'").lexeme;
        consume(TokenKind::import_keyword, "Need 'import' after module name");
        std::vector<std::string> names;
        do {
            names.push_back(consume(TokenKind::identifier, "Need imported name").lexeme);
        } while (match(TokenKind::comma));
        expect_newline("from...import");
        return std::make_unique<FromImportStmt>(k.location, module, std::move(names));
    }

    // `import module` or `import "file.luma"`
    std::string module;
    if (check(TokenKind::text))
        module = advance().lexeme;
    else
        module = consume(TokenKind::identifier, "Need module name or 'file.luma' after import").lexeme;
    expect_newline("import");
    return std::make_unique<ImportStmt>(k.location, std::move(module));
}

// ── try / except / finally ────────────────────────────────────────────

StmtPtr Parser::try_statement() {
    Token k = advance(); // skip 'try'
    consume(TokenKind::colon, "Need ':' after 'try'");
    StmtList try_body = suite("try block");

    std::vector<TryStmt::ExceptHandler> handlers;
    while (match(TokenKind::except_keyword)) {
        TryStmt::ExceptHandler handler;
        // Optional exception type
        if (!check(TokenKind::colon)) {
            handler.type = expression();
            // Optional `as name`
            if (match(TokenKind::as_keyword)) {
                handler.variable = consume(TokenKind::identifier, "Need variable name after 'as'").lexeme;
            }
        }
        consume(TokenKind::colon, "Need ':' after 'except'");
        handler.body = suite("except block");
        handlers.push_back(std::move(handler));
    }

    StmtList finally_body;
    if (match(TokenKind::finally_keyword)) {
        consume(TokenKind::colon, "Need ':' after 'finally'");
        finally_body = suite("finally block");
    }

    return std::make_unique<TryStmt>(k.location, std::move(try_body),
                                      std::move(handlers), std::move(finally_body));
}

// ── with expr as name: ────────────────────────────────────────────────

StmtPtr Parser::with_statement() {
    Token k = advance(); // skip 'with'
    ExprPtr context = expression();
    consume(TokenKind::as_keyword, "Need 'as' after context expression");
    std::string variable = consume(TokenKind::identifier, "Need variable name after 'as'").lexeme;
    consume(TokenKind::colon, "Need ':' after 'with' header");
    return std::make_unique<WithStmt>(k.location, std::move(context), std::move(variable), suite("with block"));
}

// ── raise ExceptionType(args) ─────────────────────────────────────────

StmtPtr Parser::raise_statement() {
    Token k = advance(); // skip 'raise'
    ExprPtr exc = expression();
    expect_newline("raise");
    return std::make_unique<RaiseStmt>(k.location, std::move(exc));
}

// ── global / nonlocal name ────────────────────────────────────────────

StmtPtr Parser::global_statement() {
    Token k = advance();
    bool is_nonlocal = (k.kind == TokenKind::nonlocal_keyword);
    const Token& name = consume(TokenKind::identifier, "Need variable name");
    expect_newline(is_nonlocal ? "nonlocal" : "global");
    return std::make_unique<GlobalStmt>(k.location, name.lexeme, is_nonlocal);
}

// ── del target ────────────────────────────────────────────────────────

StmtPtr Parser::del_statement() {
    Token k = advance();
    ExprPtr target = expression();
    expect_newline("del");
    return std::make_unique<DelStmt>(k.location, std::move(target));
}

// ── print(...) or legacy show ... ─────────────────────────────────────

StmtPtr Parser::print_statement() {
    Token k = advance(); // skip 'show' or 'print'
    ExprPtr v = expression();
    expect_newline("print/show");
    return std::make_unique<PrintStmt>(k.location, std::move(v));
}

// ── Expression statement ──────────────────────────────────────────────

StmtPtr Parser::expression_statement() {
    ExprPtr value = expression();
    // `list[index] = value` or `obj.attr = value` followed by `=`
    if (match(TokenKind::equal)) {
        // Check for index assignment: base[index] = value
        if (auto *idx = dynamic_cast<IndexExpr *>(value.get())) {
            ExprPtr next_value = expression();
            expect_newline("assignment");
            return std::make_unique<IndexAssignStmt>(value->location, std::move(idx->base),
                                                      std::move(idx->index), std::move(next_value));
        }
        // Check for dot assignment: obj.attr = value
        if (auto *dot = dynamic_cast<DotExpr *>(value.get())) {
            ExprPtr next_value = expression();
            expect_newline("assignment");
            return std::make_unique<DotAssignStmt>(value->location, std::move(dot->object),
                                                    std::move(dot->attribute), std::move(next_value));
        }
        fail("Invalid assignment target", value->location);
    }
    expect_newline("expression");
    return std::make_unique<ExprStmt>(value->location, std::move(value));
}

// ── Block / suite ─────────────────────────────────────────────────────

StmtList Parser::block() {
    skip_newlines();
    consume(TokenKind::indent, "Expected an indented block");
    StmtList statements;
    while (!check(TokenKind::dedent) && !check(TokenKind::end)) {
        statements.push_back(statement());
        skip_newlines();
    }
    consume(TokenKind::dedent, "Expected the block to end");
    return statements;
}

StmtList Parser::suite(const char *what) {
    if (check(TokenKind::newline)) {
        expect_newline(what);
        return block();
    }
    // Inline body: `if x: print("yes"); count += 1`
    StmtList statements;
    do {
        statements.push_back(statement());
    } while (!last_terminator_was_newline_ && !check(TokenKind::end));
    return statements;
}

// ── Expression parsing ────────────────────────────────────────────────

ExprPtr Parser::expression() { return lambda_expression(); }

// Lambda: `lambda x, y: x + y`
ExprPtr Parser::lambda_expression() {
    if (match(TokenKind::lambda_keyword)) {
        auto params = parse_parameter_list();
        consume(TokenKind::colon, "Need ':' after lambda parameters");
        ExprPtr body = expression();
        return std::make_unique<LambdaExpr>(peek().location, std::move(params), std::move(body));
    }
    return ternary_expression();
}

// Ternary: `a if cond else b` (Python-style: value_if_true if condition else value_if_false)
ExprPtr Parser::ternary_expression() {
    ExprPtr true_value = or_expression();
    if (match(TokenKind::if_keyword)) {
        ExprPtr condition = or_expression();
        consume(TokenKind::else_keyword, "Need 'else' in ternary expression");
        ExprPtr false_value = expression();
        return std::make_unique<TernaryExpr>(true_value->location, std::move(condition),
                                              std::move(true_value), std::move(false_value));
    }
    return true_value;
}

ExprPtr Parser::or_expression() {
    ExprPtr left = and_expression();
    while (check(TokenKind::or_keyword)) {
        Token op = advance();
        ExprPtr right = and_expression();
        left = std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

ExprPtr Parser::and_expression() {
    ExprPtr left = not_expression();
    while (check(TokenKind::and_keyword)) {
        Token op = advance();
        ExprPtr right = not_expression();
        left = std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

ExprPtr Parser::not_expression() {
    if (check(TokenKind::not_keyword)) {
        Token op = advance();
        ExprPtr operand = not_expression();
        return std::make_unique<UnaryExpr>(op.location, op.kind, std::move(operand));
    }
    return comparison();
}

ExprPtr Parser::comparison() {
    ExprPtr left = bitwise_or();
    while (check(TokenKind::equal_equal) || check(TokenKind::bang_equal) ||
           check(TokenKind::less) || check(TokenKind::less_equal) ||
           check(TokenKind::greater) || check(TokenKind::greater_equal) ||
           check(TokenKind::is_keyword)) {
        Token op = advance();
        // `is not` -> treat as `is` + `not` (special case)
        if (op.kind == TokenKind::is_keyword && match(TokenKind::not_keyword)) {
            // TODO: implement `is not` properly
        }
        ExprPtr right = bitwise_or();
        left = std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

ExprPtr Parser::bitwise_or() {
    ExprPtr left = bitwise_xor();
    while (check(TokenKind::pipe)) {
        Token op = advance();
        ExprPtr right = bitwise_xor();
        left = std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

ExprPtr Parser::bitwise_xor() {
    ExprPtr left = bitwise_and();
    while (check(TokenKind::caret)) {
        Token op = advance();
        ExprPtr right = bitwise_and();
        left = std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

ExprPtr Parser::bitwise_and() {
    ExprPtr left = shift_expression();
    while (check(TokenKind::ampersand)) {
        Token op = advance();
        ExprPtr right = shift_expression();
        left = std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

ExprPtr Parser::shift_expression() {
    ExprPtr left = term();
    while (check(TokenKind::left_shift) || check(TokenKind::right_shift)) {
        Token op = advance();
        ExprPtr right = term();
        left = std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

ExprPtr Parser::term() {
    ExprPtr left = factor();
    while (check(TokenKind::plus) || check(TokenKind::minus)) {
        Token op = advance();
        ExprPtr right = factor();
        left = std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

ExprPtr Parser::factor() {
    ExprPtr left = unary();
    while (check(TokenKind::star) || check(TokenKind::slash) || check(TokenKind::double_slash) ||
           check(TokenKind::percent) || check(TokenKind::at_op)) {
        Token op = advance();
        ExprPtr right = unary();
        left = std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

ExprPtr Parser::unary() {
    if (check(TokenKind::minus) || check(TokenKind::plus) || check(TokenKind::tilde)) {
        Token op = advance();
        ExprPtr right = unary();
        return std::make_unique<UnaryExpr>(op.location, op.kind, std::move(right));
    }
    return power();
}

// `a ** b` (right-associative)
ExprPtr Parser::power() {
    ExprPtr left = postfix();
    if (check(TokenKind::star_star)) {
        Token op = advance();
        ExprPtr right = unary(); // right-associative
        return std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

// Postfix: `x[i]`, `x.attr`, `x(...)`, `x++`, `x--`
ExprPtr Parser::postfix() {
    ExprPtr expr = primary();
    while (true) {
        if (check(TokenKind::left_bracket)) {
            Token bracket = advance();
            ExprPtr index = expression();
            consume(TokenKind::right_bracket, "Need ']' after index");
            expr = std::make_unique<IndexExpr>(bracket.location, std::move(expr), std::move(index));
        }
        else if (check(TokenKind::dot)) {
            advance();
            const Token& attr = consume(TokenKind::identifier, "Need attribute name after '.'");
            expr = std::make_unique<DotExpr>(attr.location, std::move(expr), attr.lexeme);
        }
        else if (check(TokenKind::left_paren)) {
            advance();
            std::vector<ExprPtr> arguments;
            if (!check(TokenKind::right_paren)) {
                do { arguments.push_back(expression()); } while (match(TokenKind::comma));
            }
            consume(TokenKind::right_paren, "Need ')' after arguments");
            expr = std::make_unique<CallExpr>(expr->location, std::move(expr), std::move(arguments));
        }
        else if (check(TokenKind::plus_plus)) {
            Token op = advance();
            auto name = dynamic_cast<NameExpr*>(expr.get());
            if (!name) fail("Can only increment a variable", op.location);
            return std::make_unique<IncDecExpr>(op.location, name->name, true);
        }
        else if (check(TokenKind::minus_minus)) {
            Token op = advance();
            auto name = dynamic_cast<NameExpr*>(expr.get());
            if (!name) fail("Can only decrement a variable", op.location);
            return std::make_unique<IncDecExpr>(op.location, name->name, false);
        }
        else {
            break;
        }
    }
    return expr;
}

// ── Primary expressions ───────────────────────────────────────────────

ExprPtr Parser::primary() {
    // Number
    if (check(TokenKind::number)) {
        Token token = advance();
        return std::make_unique<LiteralExpr>(token.location, Value{std::stod(token.lexeme)});
    }
    // Text
    if (check(TokenKind::text)) {
        Token token = advance();
        return std::make_unique<LiteralExpr>(token.location, Value{token.lexeme});
    }
    // F-string
    if (check(TokenKind::fstring)) {
        Token token = advance();
        // For now, treat f-string as a simple string (TODO: proper interpolation)
        return std::make_unique<LiteralExpr>(token.location, Value{token.lexeme});
    }
    // True / False / None
    if (check(TokenKind::true_keyword)) {
        Token token = advance();
        return std::make_unique<LiteralExpr>(token.location, Value{true});
    }
    if (check(TokenKind::false_keyword)) {
        Token token = advance();
        return std::make_unique<LiteralExpr>(token.location, Value{false});
    }
    if (check(TokenKind::none_keyword)) {
        Token token = advance();
        return std::make_unique<LiteralExpr>(token.location, Value{});
    }
    // Legacy: true/false/nothing (lowercase)
    if (check(TokenKind::identifier) && peek().lexeme == "true") {
        Token token = advance();
        return std::make_unique<LiteralExpr>(token.location, Value{true});
    }
    if (check(TokenKind::identifier) && peek().lexeme == "false") {
        Token token = advance();
        return std::make_unique<LiteralExpr>(token.location, Value{false});
    }
    if (check(TokenKind::identifier) && peek().lexeme == "nothing") {
        Token token = advance();
        return std::make_unique<LiteralExpr>(token.location, Value{});
    }
    // List literal: [1, 2, 3] or list comprehension [x for x in items if x > 2]
    if (check(TokenKind::left_bracket)) {
        Token bracket = advance();
        // Empty list: []
        if (check(TokenKind::right_bracket)) {
            advance();
            return std::make_unique<ListExpr>(bracket.location, std::vector<ExprPtr>{});
        }
        ExprPtr first = expression();
        // List comprehension: [expr for var in iterable if cond]
        if (check(TokenKind::for_keyword)) {
            advance(); // skip 'for'
            const Token& var = consume(TokenKind::identifier, "Need variable name after 'for'");
            consume(TokenKind::in_keyword, "Need 'in' after variable name");
            // Use or_expression to avoid consuming 'if' as ternary
            ExprPtr iterable = or_expression();
            ExprPtr condition;
            if (match(TokenKind::if_keyword)) {
                condition = or_expression();
            }
            consume(TokenKind::right_bracket, "Need ']' after list comprehension");
            return std::make_unique<ListCompExpr>(bracket.location, std::move(first),
                                                   var.lexeme, std::move(iterable), std::move(condition));
        }
        // Regular list: [a, b, c]
        std::vector<ExprPtr> items;
        items.push_back(std::move(first));
        while (match(TokenKind::comma)) {
            items.push_back(expression());
        }
        consume(TokenKind::right_bracket, "Need ']' after list items");
        return std::make_unique<ListExpr>(bracket.location, std::move(items));
    }
    // Dict literal: {"key": value} or set literal: {1, 2, 3}
    if (check(TokenKind::left_brace)) {
        Token brace = advance();
        // Empty dict: {}
        if (check(TokenKind::right_brace)) {
            advance();
            return std::make_unique<DictExpr>(brace.location, std::vector<ExprPtr>{}, std::vector<ExprPtr>{});
        }
        // Try to determine if it's a dict or set
        ExprPtr first = expression();
        if (match(TokenKind::colon)) {
            // It's a dict
            std::vector<ExprPtr> keys;
            std::vector<ExprPtr> values;
            keys.push_back(std::move(first));
            values.push_back(expression());
            while (match(TokenKind::comma)) {
                if (check(TokenKind::right_brace)) break;
                ExprPtr key = expression();
                consume(TokenKind::colon, "Need ':' in dict literal");
                ExprPtr val = expression();
                keys.push_back(std::move(key));
                values.push_back(std::move(val));
            }
            consume(TokenKind::right_brace, "Need '}' after dict items");
            return std::make_unique<DictExpr>(brace.location, std::move(keys), std::move(values));
        } else {
            // It's a set
            std::vector<ExprPtr> items;
            items.push_back(std::move(first));
            while (match(TokenKind::comma)) {
                if (check(TokenKind::right_brace)) break;
                items.push_back(expression());
            }
            consume(TokenKind::right_brace, "Need '}' after set items");
            return std::make_unique<SetExpr>(brace.location, std::move(items));
        }
    }
    // Parenthesized expression or tuple
    if (check(TokenKind::left_paren)) {
        advance();
        if (check(TokenKind::right_paren)) {
            advance();
            return std::make_unique<TupleExpr>(peek().location, std::vector<ExprPtr>{});
        }
        ExprPtr first = expression();
        if (match(TokenKind::comma)) {
            // Tuple
            std::vector<ExprPtr> items;
            items.push_back(std::move(first));
            if (!check(TokenKind::right_paren)) {
                do { items.push_back(expression()); } while (match(TokenKind::comma));
            }
            consume(TokenKind::right_paren, "Need ')' after tuple");
            return std::make_unique<TupleExpr>(first->location, std::move(items));
        }
        consume(TokenKind::right_paren, "Need ')' to close expression");
        return first;
    }
    // Ellipsis
    if (check(TokenKind::ellipsis)) {
        Token token = advance();
        return std::make_unique<LiteralExpr>(token.location, Value{std::string("...")});
    }
    // Identifier / function call
    if (check(TokenKind::identifier)) {
        Token name = advance();
        return std::make_unique<NameExpr>(name.location, name.lexeme);
    }

    fail("Expected a value here", peek().location);
}

// ── Helpers ───────────────────────────────────────────────────────────

std::vector<std::string> Parser::parse_parameter_list() {
    std::vector<std::string> params;
    if (!check(TokenKind::right_paren)) {
        do {
            params.push_back(consume(TokenKind::identifier, "Need parameter name").lexeme);
        } while (match(TokenKind::comma));
    }
    return params;
}

std::vector<ExprPtr> Parser::parse_argument_list() {
    std::vector<ExprPtr> args;
    if (!check(TokenKind::right_paren)) {
        do { args.push_back(expression()); } while (match(TokenKind::comma));
    }
    return args;
}

void Parser::skip_newlines() {
    while (check(TokenKind::newline)) advance();
}

void Parser::expect_newline(const char *what) {
    if (check(TokenKind::semicolon)) {
        advance();
        last_terminator_was_newline_ = false;
        if (check(TokenKind::newline)) {
            advance();
            last_terminator_was_newline_ = true;
        }
        return;
    }
    if (check(TokenKind::newline) || check(TokenKind::end) || check(TokenKind::dedent)) {
        if (check(TokenKind::newline)) advance();
        last_terminator_was_newline_ = true;
        return;
    }
    fail(std::string{"Expected a new line (or ;) after "} + what, peek().location);
}

bool Parser::match(TokenKind kind) {
    if (!check(kind)) return false;
    advance();
    return true;
}

bool Parser::check(TokenKind kind) const { return peek().kind == kind; }

const Token &Parser::advance() {
    if (!check(TokenKind::end)) ++current_;
    return previous();
}

const Token &Parser::peek() const { return tokens_.at(current_); }

const Token &Parser::previous() const { return tokens_.at(current_ - 1); }

const Token &Parser::consume(TokenKind kind, const std::string &message) {
    if (check(kind)) return advance();
    fail(message + " (found " + std::string{token_name(peek().kind)} + ")", peek().location);
}

}
