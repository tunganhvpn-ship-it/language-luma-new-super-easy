// Luma VM Stub — Self-extracting executable runner
// This program reads bytecode appended to itself and runs it on the VM.
// When `luma build` creates a standalone .exe, it:
//   1. Copies this pre-compiled VM stub
//   2. Appends serialized bytecode after the PE header
//   3. The resulting .exe is fully self-contained
//
// Binary format (appended after PE):
//   [4 bytes: magic "LUMA"]
//   [4 bytes: bytecode size (little-endian)]
//   [N bytes: bytecode data]

#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

#ifdef _WIN32
#include <windows.h>
#endif

#include "luma/bytecode/chunk.hpp"
#include "luma/bytecode/opcode.hpp"
#include "luma/runtime/value.hpp"
#include "luma/runtime/vm.hpp"
#include "luma/version.hpp"

namespace
{

    constexpr char MAGIC[] = {'L', 'U', 'M', 'A'};

    // Read the bytecode that was appended to this executable
    std::pair<std::vector<unsigned char>, bool> read_self_bytecode()
    {
        // Get path to this executable
        char exe_path[MAX_PATH] = {0};
#ifdef _WIN32
        GetModuleFileNameA(nullptr, exe_path, MAX_PATH);
#else
        // Fallback for non-Windows (shouldn't be used here)
        return {{}, false};
#endif

        std::ifstream file(exe_path, std::ios::binary | std::ios::ate);
        if (!file.is_open())
            return {{}, false};

        const std::streamsize file_size = file.tellg();
        if (file_size < 8) // Minimum: 4 magic + 4 size
            return {{}, false};

        // Read last 8 bytes: magic (4) + size (4)
        file.seekg(file_size - 8);
        char header[8];
        file.read(header, 8);

        // Verify magic
        if (std::memcmp(header, MAGIC, 4) != 0)
            return {{}, false};

        // Read bytecode size (little-endian)
        uint32_t bytecode_size = 0;
        bytecode_size |= static_cast<uint32_t>(static_cast<unsigned char>(header[4]));
        bytecode_size |= static_cast<uint32_t>(static_cast<unsigned char>(header[5])) << 8;
        bytecode_size |= static_cast<uint32_t>(static_cast<unsigned char>(header[6])) << 16;
        bytecode_size |= static_cast<uint32_t>(static_cast<unsigned char>(header[7])) << 24;

        if (bytecode_size == 0 || static_cast<std::streamsize>(bytecode_size) > file_size - 8)
            return {{}, false};

        // Read bytecode
        file.seekg(file_size - 8 - bytecode_size);
        std::vector<unsigned char> bytecode(bytecode_size);
        file.read(reinterpret_cast<char *>(bytecode.data()), bytecode_size);

        return {bytecode, true};
    }

    // Deserialize a Chunk from binary data
    class BytecodeReader
    {
    public:
        explicit BytecodeReader(const unsigned char *data, std::size_t size)
            : data_(data), size_(size), pos_(0) {}

        luma::Chunk read_chunk()
        {
            luma::Chunk chunk;
            // Constants
            std::uint32_t const_count = read_u32();
            for (std::uint32_t i = 0; i < const_count; ++i)
                chunk.add_constant(read_value());
            // Names
            std::uint32_t name_count = read_u32();
            for (std::uint32_t i = 0; i < name_count; ++i)
                chunk.add_name(read_string());
            // Instructions
            std::uint32_t instr_count = read_u32();
            for (std::uint32_t i = 0; i < instr_count; ++i)
            {
                luma::OpCode op = static_cast<luma::OpCode>(read_u8());
                std::size_t a = read_u64();
                std::size_t b = read_u64();
                chunk.emit(op, a, b, {0, 0});
            }
            // Functions (recursive)
            std::uint32_t func_count = read_u32();
            for (std::uint32_t i = 0; i < func_count; ++i)
            {
                std::vector<std::string> params;
                std::uint32_t param_count = read_u32();
                for (std::uint32_t j = 0; j < param_count; ++j)
                    params.push_back(read_string());
                luma::Chunk body = read_chunk();
                chunk.add_function(std::move(params), std::move(body));
            }
            return chunk;
        }

    private:
        std::uint8_t read_u8() { return data_[pos_++]; }
        std::uint32_t read_u32()
        {
            std::uint32_t v = 0;
            v |= static_cast<std::uint32_t>(data_[pos_]);
            v |= static_cast<std::uint32_t>(data_[pos_ + 1]) << 8;
            v |= static_cast<std::uint32_t>(data_[pos_ + 2]) << 16;
            v |= static_cast<std::uint32_t>(data_[pos_ + 3]) << 24;
            pos_ += 4;
            return v;
        }
        std::size_t read_u64()
        {
            std::size_t v = 0;
            for (int i = 0; i < 8; ++i)
                v |= static_cast<std::size_t>(data_[pos_ + i]) << (i * 8);
            pos_ += 8;
            return v;
        }
        std::string read_string()
        {
            std::uint32_t len = read_u32();
            std::string s(reinterpret_cast<const char *>(&data_[pos_]), len);
            pos_ += len;
            return s;
        }
        luma::Value read_value()
        {
            std::uint8_t tag = read_u8();
            switch (tag)
            {
            case 0:
                return luma::Value{}; // nothing
            case 1:
            {
                bool b = read_u8() != 0;
                return luma::Value{b};
            }
            case 2:
            {
                std::uint64_t bits = 0;
                for (int i = 0; i < 8; ++i)
                    bits |= static_cast<std::uint64_t>(data_[pos_ + i]) << (i * 8);
                pos_ += 8;
                double num;
                std::memcpy(&num, &bits, sizeof(num));
                return luma::Value{num};
            }
            case 3:
                return luma::Value{read_string()};
            case 4:
            {
                std::uint32_t count = read_u32();
                auto list = std::make_shared<std::vector<luma::Value>>();
                for (std::uint32_t i = 0; i < count; ++i)
                    list->push_back(read_value());
                return luma::Value{list};
            }
            default:
                throw std::runtime_error("Invalid bytecode tag");
            }
        }
        const unsigned char *data_;
        std::size_t size_;
        std::size_t pos_;
    };

}

int main()
{
    try
    {
        // Read bytecode appended to this executable
        auto [bytecode, success] = read_self_bytecode();
        if (!success)
        {
            std::cerr << "Luma VM " << luma::version << "\n\n"
                      << "This is the pre-compiled VM stub for Luma.\n"
                      << "It runs standalone executables created by 'luma build'.\n\n"
                      << "Usage:\n"
                      << "  luma build <file.luma>     Create a standalone .exe\n"
                      << "  <built-program>.exe         Run a built program\n";
            return 1;
        }

        // Deserialize and run
        BytecodeReader reader(bytecode.data(), bytecode.size());
        luma::Chunk chunk = reader.read_chunk();
        luma::VirtualMachine{}.run(chunk);
        return 0;
    }
    catch (const std::exception &error)
    {
        std::cerr << "Luma runtime error: " << error.what() << '\n';
        return 1;
    }
}
