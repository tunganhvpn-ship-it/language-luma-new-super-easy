#include "luma/app/bundler.hpp"

#include <array>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iostream>

namespace luma::bundler
{
    namespace
    {

        // ── Binary format constants ────────────────────────────────────────
        constexpr std::array<char, 4> MAGIC = {'L', 'U', 'M', 'A'};

        // Value type tags for serialization
        constexpr std::uint8_t TAG_NOTHING = 0;
        constexpr std::uint8_t TAG_BOOL = 1;
        constexpr std::uint8_t TAG_NUMBER = 2;
        constexpr std::uint8_t TAG_TEXT = 3;
        constexpr std::uint8_t TAG_LIST = 4;

        // ── Byte-level writers ─────────────────────────────────────────────

        void write_u8(std::string &out, std::uint8_t value)
        {
            out.push_back(static_cast<char>(value));
        }

        void write_u32(std::string &out, std::uint32_t value)
        {
            out.push_back(static_cast<char>(value & 0xFF));
            out.push_back(static_cast<char>((value >> 8) & 0xFF));
            out.push_back(static_cast<char>((value >> 16) & 0xFF));
            out.push_back(static_cast<char>((value >> 24) & 0xFF));
        }

        void write_u64(std::string &out, std::uint64_t value)
        {
            for (int i = 0; i < 8; ++i)
                out.push_back(static_cast<char>((value >> (i * 8)) & 0xFF));
        }

        void write_bytes(std::string &out, const char *data, std::size_t length)
        {
            out.append(data, length);
        }

        // ── Value serialization ────────────────────────────────────────────

        void serialize_value(std::string &out, const Value &value)
        {
            if (value.is_number())
            {
                write_u8(out, TAG_NUMBER);
                double number = value.as_number();
                write_u64(out, *reinterpret_cast<const std::uint64_t *>(&number));
            }
            else if (value.is_text())
            {
                write_u8(out, TAG_TEXT);
                const std::string &text = value.as_text();
                write_u32(out, static_cast<std::uint32_t>(text.size()));
                write_bytes(out, text.data(), text.size());
            }
            else if (value.is_list())
            {
                write_u8(out, TAG_LIST);
                const auto &items = value.as_list();
                write_u32(out, static_cast<std::uint32_t>(items.size()));
                for (const auto &item : items)
                    serialize_value(out, item);
            }
            else if (std::holds_alternative<bool>(value.storage()))
            {
                write_u8(out, TAG_BOOL);
                write_u8(out, value.truthy() ? 1 : 0);
            }
            else
            {
                write_u8(out, TAG_NOTHING);
            }
        }

        // ── Chunk serialization (recursive for nested functions) ───────────

        void serialize_chunk(std::string &out, const Chunk &chunk)
        {
            // Constants
            const auto &constants = chunk.constants();
            write_u32(out, static_cast<std::uint32_t>(constants.size()));
            for (const auto &constant : constants)
                serialize_value(out, constant);

            // Names
            const auto &names = chunk.names();
            write_u32(out, static_cast<std::uint32_t>(names.size()));
            for (const auto &name : names)
            {
                write_u32(out, static_cast<std::uint32_t>(name.size()));
                write_bytes(out, name.data(), name.size());
            }

            // Instructions
            const auto &instructions = chunk.instructions();
            write_u32(out, static_cast<std::uint32_t>(instructions.size()));
            for (const auto &instr : instructions)
            {
                write_u8(out, static_cast<std::uint8_t>(instr.opcode));
                write_u64(out, instr.operand_a);
                write_u64(out, instr.operand_b);
            }

            // Functions (recursive)
            write_u32(out, static_cast<std::uint32_t>(chunk.function_count()));
            for (std::size_t i = 0; i < chunk.function_count(); ++i)
            {
                const auto &func = chunk.function(i);
                // Parameter names
                write_u32(out, static_cast<std::uint32_t>(func.param_names.size()));
                for (const auto &param : func.param_names)
                {
                    write_u32(out, static_cast<std::uint32_t>(param.size()));
                    write_bytes(out, param.data(), param.size());
                }
                // Body chunk (recursive)
                serialize_chunk(out, func.body);
            }
        }

        // ── Find VM stub ───────────────────────────────────────────────────

        std::filesystem::path find_vm_stub(const std::filesystem::path &exe_dir)
        {
            namespace fs = std::filesystem;

            // Try locations relative to the luma.exe
            const fs::path candidates[] = {
                exe_dir / "luma_vm.exe",
                exe_dir / ".." / "luma_vm.exe",
                exe_dir / ".." / "out" / "luma_vm.exe",
                exe_dir / ".." / "bin" / "luma_vm.exe",
            };

            for (const auto &candidate : candidates)
            {
                std::error_code ignored;
                if (fs::exists(candidate, ignored))
                    return candidate;
            }

            // Fallback: just return the expected name
            return exe_dir / "luma_vm.exe";
        }

    }

    std::string serialize_chunk(const Chunk &chunk)
    {
        std::string data;
        // Header
        write_bytes(data, MAGIC.data(), 4);
        // Body
        serialize_chunk(data, chunk);
        return data;
    }

    // v0.4: Self-extracting approach — append bytecode to pre-compiled VM stub.
    // No C++ compiler needed at build time!
    bool bundle_executable(const Chunk &chunk, const std::string &output_path,
                           const std::filesystem::path &exe_dir)
    {
        namespace fs = std::filesystem;

        // 1. Serialize bytecode
        const std::string bytecode = serialize_chunk(chunk);

        // 2. Find VM stub
        const fs::path vm_stub = find_vm_stub(exe_dir);
        if (!fs::exists(vm_stub))
        {
            std::cerr << "Luma: VM stub not found at " << vm_stub << "\n\n"
                      << "To build standalone executables, luma_vm.exe must be\n"
                      << "in the same directory as luma.exe.\n\n"
                      << "Build the project with:\n"
                      << "  cmake --build build\n\n"
                      << "This will create both luma.exe and luma_vm.exe in out/.\n";
            return false;
        }

        // 3. Read VM stub
        std::ifstream stub_stream(vm_stub, std::ios::binary);
        if (!stub_stream)
        {
            std::cerr << "Luma: Could not read VM stub: " << vm_stub << "\n";
            return false;
        }
        std::string stub_data((std::istreambuf_iterator<char>(stub_stream)),
                              std::istreambuf_iterator<char>());
        stub_stream.close();

        // 4. Create output: VM stub + [magic:4][size:4][bytecode:N]
        std::ofstream out_stream(output_path, std::ios::binary);
        if (!out_stream)
        {
            std::cerr << "Luma: Could not create output: " << output_path << "\n";
            return false;
        }

        // Write VM stub
        out_stream.write(stub_data.data(), stub_data.size());

        // Write bytecode size (little-endian)
        uint32_t bytecode_size = static_cast<uint32_t>(bytecode.size());
        char size_bytes[4];
        size_bytes[0] = static_cast<char>(bytecode_size & 0xFF);
        size_bytes[1] = static_cast<char>((bytecode_size >> 8) & 0xFF);
        size_bytes[2] = static_cast<char>((bytecode_size >> 16) & 0xFF);
        size_bytes[3] = static_cast<char>((bytecode_size >> 24) & 0xFF);

        // Write magic + size + bytecode
        out_stream.write(MAGIC.data(), 4);
        out_stream.write(size_bytes, 4);
        out_stream.write(bytecode.data(), bytecode.size());
        out_stream.close();

        // 5. Make executable writable (on Windows, the copy should already be executable)
        std::error_code ignored;
        fs::permissions(output_path, fs::perms::owner_read | fs::perms::owner_write | fs::perms::owner_exec,
                        fs::perm_options::replace, ignored);

        return true;
    }

}
