#include "luma/app/application.hpp"

#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>

#include "luma/app/bundler.hpp"
#include "luma/build_config.hpp"
#include "luma/bytecode/compiler.hpp"
#include "luma/core/diagnostic.hpp"
#include "luma/core/source.hpp"
#include "luma/lex/lexer.hpp"
#include "luma/parse/parser.hpp"
#include "luma/runtime/vm.hpp"
#include "luma/version.hpp"

namespace luma
{
    namespace
    {

        void print_usage()
        {
            std::cout << "Luma " << version << " -- a small, readable, Python-like language\n\n"
                       << "Usage:\n"
                       << "  luma <file.luma>            Run a program with the interpreter\n"
                       << "  luma run <file.luma>        Same as above, explicit form\n"
                       << "  luma build <file.luma> [-o output]\n"
                       << "                              Bundle into a standalone executable\n"
                       << "  luma init [name]            Create a starter project\n"
                       << "  luma info                   Show language info\n"
                       << "  luma --debug <file.luma>    Run with timing info\n"
                       << "  luma --version              Print the version\n"
                       << "  luma --help                 Show this message\n\n"
                       << "Architecture (v0.6):\n"
                       << "  Interpreter:  Source -> Bytecode -> VM\n"
                       << "  Build:        Source -> Bytecode -> Bundle VM + bytecode -> .exe\n"
                       << "  No C++ compiler needed at build time!\n";
        }

        void print_info()
        {
            std::cout << "Luma " << version << "\n\n"
                      << "Architecture:  Bytecode VM with Self-Extracting Executables\n"
                      << "Standard:      C++23\n"
                      << "Extensions:    .luma\n\n"
                      << "Commands:\n"
                      << "  luma run <file>      Run on bytecode VM\n"
                      << "  luma build <file>    Build standalone .exe\n"
                      << "  luma init [name]     Create starter project\n"
                      << "  luma info            Show this info\n\n"
                      << "Built-in functions:\n"
                      << "\n  Core & I/O\n"
                      << "    print()         input()         read_file()     write_file()\n"
                      << "    type_of()       length()        text()          number()\n"
                      << "    assert()        sleep_ms()      now_ms()\n"
                      << "\n  Type checking\n"
                      << "    is_number()     is_text()       is_list()       is_nothing()\n"
                      << "\n  Lists\n"
                      << "    push()          pop()           sort()          sorted()\n"
                      << "    reverse()       reversed()      unique()        flatten()\n"
                      << "    count()         sum()           product()       average()\n"
                      << "    min_of()        max_of()        range()\n"
                      << "    contains()      find()          slice()\n"
                      << "    enumerate()     zip()           any()           all()\n"
                      << "\n  Text\n"
                      << "    join()          split()         upper()         lower()\n"
                      << "    trim()          replace()       starts_with()   ends_with()\n"
                      << "    char_at()       to_char()       ord()\n"
                      << "\n  Math\n"
                      << "    abs()           sqrt()          floor()         ceil()\n"
                      << "    round()         pow()           min()           max()\n"
                      << "    random()        clamp()\n"
                      << "\n  Graphics (SDL2)\n"
                      << "    window_open()   window_close()  window_clear()\n"
                      << "    window_set_pixel()  window_fill_rect()  window_draw_line()\n"
                      << "    window_present()    window_should_close()\n";
        }

        Program parse_source(const std::string &source)
        {
            const auto tokens = Lexer{source}.scan();
            return Parser{tokens}.parse();
        }

        void load_into(const std::filesystem::path &path, Program &merged,
                       std::vector<std::filesystem::path> &loaded)
        {
            namespace fs = std::filesystem;
            std::error_code ignored;
            fs::path canonical = fs::weakly_canonical(path, ignored);
            if (canonical.empty())
                canonical = fs::absolute(path);
            for (const auto &existing : loaded)
                if (existing == canonical)
                    return;
            loaded.push_back(canonical);

            const std::string source = read_source_file(path.string());
            Program program = parse_source(source);
            for (auto &statement : program.statements)
            {
                if (const auto *import_stmt = dynamic_cast<const ImportStmt *>(statement.get()))
                {
                    fs::path module_path{import_stmt->module};
                    if (!module_path.has_extension())
                        module_path += ".luma";
                    load_into(path.parent_path() / module_path, merged, loaded);
                    continue;
                }
                if (const auto *from_import = dynamic_cast<const FromImportStmt *>(statement.get()))
                {
                    fs::path module_path{from_import->module};
                    if (!module_path.has_extension())
                        module_path += ".luma";
                    load_into(path.parent_path() / module_path, merged, loaded);
                    continue;
                }
                merged.statements.push_back(std::move(statement));
            }
        }

        Program load_program(const std::string &path)
        {
            Program merged;
            std::vector<std::filesystem::path> loaded;
            load_into(std::filesystem::path{path}, merged, loaded);
            return merged;
        }

        // ── Commands ─────────────────────────────────────────────────────

        int run_file(const std::string &path)
        {
            try
            {
                const auto program = load_program(path);
                const auto chunk = Compiler{}.compile(program);
                VirtualMachine{}.run(chunk);
                return 0;
            }
            catch (const Diagnostic &error)
            {
                std::cerr << path << ": " << error.what() << '\n';
                return 1;
            }
            catch (const std::exception &error)
            {
                std::cerr << "Luma: " << error.what() << '\n';
                return 1;
            }
        }

        int run_file_debug(const std::string &path)
        {
            try
            {
                auto t0 = std::chrono::steady_clock::now();
                const auto program = load_program(path);
                auto t1 = std::chrono::steady_clock::now();
                const auto chunk = Compiler{}.compile(program);
                auto t2 = std::chrono::steady_clock::now();
                VirtualMachine{}.run(chunk);
                auto t3 = std::chrono::steady_clock::now();

                auto ms = [](auto a, auto b) {
                    return std::chrono::duration<double, std::milli>(b - a).count();
                };
                std::cerr << "\n--- Timing ---\n"
                          << "  Parse:    " << ms(t0, t1) << " ms\n"
                          << "  Compile:  " << ms(t1, t2) << " ms\n"
                          << "  Execute:  " << ms(t2, t3) << " ms\n"
                          << "  Total:    " << ms(t0, t3) << " ms\n";
                return 0;
            }
            catch (const Diagnostic &error)
            {
                std::cerr << path << ": " << error.what() << '\n';
                return 1;
            }
            catch (const std::exception &error)
            {
                std::cerr << "Luma: " << error.what() << '\n';
                return 1;
            }
        }

        int build_file(const std::string &source_path, std::string output_path, const std::filesystem::path &exe_dir)
        {
            Chunk chunk;
            try
            {
                const auto program = load_program(source_path);
                chunk = Compiler{}.compile(program);
            }
            catch (const Diagnostic &error)
            {
                std::cerr << source_path << ": " << error.what() << '\n';
                return 1;
            }
            catch (const std::exception &error)
            {
                std::cerr << source_path << ": " << error.what() << '\n';
                return 1;
            }

            const std::filesystem::path source_file{source_path};
            if (output_path.empty())
            {
                std::filesystem::path candidate = source_file;
#ifdef _WIN32
                candidate.replace_extension(".exe");
#else
                candidate.replace_extension("");
#endif
                output_path = candidate.string();
            }

            std::cout << "Luma: bundling " << source_path << " -> " << output_path << '\n';

            if (!bundler::bundle_executable(chunk, output_path, exe_dir))
            {
                std::cerr << "Luma: build failed.\n";
                return 1;
            }

            const std::uintmax_t file_size = std::filesystem::file_size(output_path);
            std::cout << "Luma: built " << output_path << " (" << file_size << " bytes)\n";
            return 0;
        }

        int init_project(const std::string &name)
        {
            namespace fs = std::filesystem;
            std::string project_name = name.empty() ? "my_luma_project" : name;
            fs::path project_dir{project_name};

            std::error_code ignored;
            if (fs::exists(project_dir, ignored) && !fs::is_empty(project_dir, ignored))
            {
                std::cerr << "Luma: directory '" << project_name << "' already exists and is not empty.\n";
                return 1;
            }

            fs::create_directories(project_dir, ignored);
            fs::create_directories(project_dir / "lib", ignored);

            // main.luma
            {
                std::ofstream main_file(project_dir / "main.luma");
                main_file << "# " << project_name << " - a Luma program\n"
                          << "# Run with: luma main.luma\n"
                          << "# Build:    luma build main.luma\n\n"
                          << "print(\"Hello from " << project_name << "!\")\n\n"
                          << "def greet(name):\n"
                          << "    print(\"Welcome, \" + name + \"!\")\n\n"
                          << "greet(\"World\")\n";
            }

            // lib/utils.luma
            {
                std::ofstream utils_file(project_dir / "lib" / "utils.luma");
                utils_file << "# Utility functions for " << project_name << "\n\n"
                           << "def add(a, b):\n"
                           << "    return a + b\n\n"
                           << "def multiply(a, b):\n"
                           << "    return a * b\n";
            }

            // README.md
            {
                std::ofstream readme(project_dir / "README.md");
                readme << "# " << project_name << "\n\n"
                       << "A Luma project.\n\n"
                       << "## Quick Start\n\n"
                       << "```bash\n"
                       << "# Run\n"
                       << "luma main.luma\n\n"
                       << "# Build standalone .exe\n"
                       << "luma build main.luma\n\n"
                       << "# Or run from editor\n"
                       << "luma-edit main.luma\n"
                       << "```\n";
            }

            std::cout << "Luma: created project '" << project_name << "'\n\n"
                      << "  " << project_name << "/\n"
                      << "  ├── main.luma      # entry point\n"
                      << "  ├── lib/\n"
                      << "  │   └── utils.luma  # utility functions\n"
                      << "  └── README.md\n\n"
                      << "Next steps:\n"
                      << "  cd " << project_name << "\n"
                      << "  luma main.luma\n";
            return 0;
        }

    }

    int Application::run(const std::vector<std::string_view> &arguments) const
    {
        if (arguments.size() < 2)
        {
            print_usage();
            return 1;
        }

        const std::string_view command = arguments[1];

        // --version / version
        if (command == "--version" || command == "version")
        {
            std::cout << "Luma " << version << " (Bytecode VM + Self-Extracting Executables)\n";
            return 0;
        }

        // --help / help
        if (command == "--help" || command == "help")
        {
            print_usage();
            return 0;
        }

        // info
        if (command == "info")
        {
            print_info();
            return 0;
        }

        // init [name]
        if (command == "init")
        {
            std::string name;
            if (arguments.size() >= 3)
                name = std::string{arguments[2]};
            return init_project(name);
        }

        // --debug <file>
        if (command == "--debug")
        {
            if (arguments.size() < 3)
            {
                std::cerr << "Usage: luma --debug <file.luma>\n";
                return 1;
            }
            return run_file_debug(std::string{arguments[2]});
        }

        // run <file>
        if (command == "run")
        {
            if (arguments.size() < 3)
            {
                std::cerr << "Usage: luma run <file.luma>\n";
                return 1;
            }
            return run_file(std::string{arguments[2]});
        }

        // build <file> [-o output]
        if (command == "build")
        {
            if (arguments.size() < 3)
            {
                std::cerr << "Usage: luma build <file.luma> [-o output]\n";
                return 1;
            }
            std::string output_path;
            for (std::size_t index = 3; index < arguments.size(); ++index)
            {
                if (arguments[index] == "-o" && index + 1 < arguments.size())
                    output_path = arguments[++index];
            }
            std::filesystem::path exe_dir;
            try
            {
                exe_dir = std::filesystem::absolute(std::filesystem::path{std::string{arguments[0]}}).parent_path();
            }
            catch (const std::exception &)
            {
                exe_dir = std::filesystem::current_path();
            }
            return build_file(std::string{arguments[2]}, output_path, exe_dir);
        }

        // Back-compatible: `luma file.luma` -> `luma run file.luma`
        return run_file(std::string{command});
    }

}
