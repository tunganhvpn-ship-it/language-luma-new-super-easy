// Luma Editor v0.5 -- a Windows code editor dedicated to the Luma language.
//
// Features:
//   * Dark theme with syntax highlighting (keywords, strings, numbers, comments, built-ins)
//   * Find (Ctrl+F) and Replace (Ctrl+H)
//   * Run (F5), Build (F6), Run Last (F7) straight from the editor
//   * Tab inserts 4 spaces (Luma indentation), Enter auto-indents
//   * UTF-8 files, open/save dialogs, unsaved-changes protection
//   * Word wrap toggle, goto line (Ctrl+G)
//   * Status bar with file, encoding, line/column, version
//
// Built as the `luma-edit.exe` target (see CMakeLists.txt).

#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif

#include <windows.h>

#include <commctrl.h>
#include <commdlg.h>
#include <richedit.h>
#include <shellapi.h>

#include <algorithm>
#include <cwctype>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_set>
#include <vector>

#ifndef MSFTEDIT_CLASS
#define MSFTEDIT_CLASS L"RICHEDIT50W"
#endif
#ifndef EM_GETSCROLLPOS
#define EM_GETSCROLLPOS (WM_USER + 221)
#endif
#ifndef EM_SETSCROLLPOS
#define EM_SETSCROLLPOS (WM_USER + 222)
#endif

namespace
{

    // ── Constants ────────────────────────────────────────────────────────
    constexpr wchar_t kWindowClass[] = L"LumaEditorWindow";
    constexpr wchar_t kAppTitle[] = L"Luma Editor v0.5";
    constexpr wchar_t kFindClass[] = L"LumaFindDialog";
    constexpr int kEditorId = 100;
    constexpr int kStatusId = 101;

    enum MenuCommand
    {
        ID_FILE_NEW = 200,
        ID_FILE_OPEN,
        ID_FILE_SAVE,
        ID_FILE_SAVEAS,
        ID_FILE_EXIT,
        ID_EDIT_UNDO,
        ID_EDIT_REDO,
        ID_EDIT_FIND,
        ID_EDIT_REPLACE,
        ID_EDIT_GOTOLINE,
        ID_EDIT_WORDWRAP,
        ID_RUN_RUN,
        ID_RUN_BUILD,
        ID_RUN_LAST,
        ID_HELP_ABOUT,
    };

    // ── Global state ─────────────────────────────────────────────────────
    HWND g_main_window = nullptr;
    HWND g_editor = nullptr;
    HWND g_status = nullptr;
    HWND g_find_dialog = nullptr;
    HWND g_find_edit = nullptr;
    HWND g_replace_edit = nullptr;
    HWND g_replace_check = nullptr;
    bool g_find_whole = false;
    std::wstring g_file_path;
    std::wstring g_last_built_exe;
    bool g_dirty = false;
    bool g_highlighting = false;
    bool g_word_wrap = true;
    constexpr UINT_PTR TIMER_HIGHLIGHT = 1;
    constexpr UINT_PTR TIMER_AUTOSAVE = 2;

    // ── Dark theme colors ────────────────────────────────────────────────
    const COLORREF kBgDark = RGB(30, 30, 30);
    const COLORREF kFgDefault = RGB(212, 212, 212);
    const COLORREF kColorKeyword = RGB(86, 156, 214);
    const COLORREF kColorString = RGB(214, 155, 131);
    const COLORREF kColorNumber = RGB(181, 113, 209);
    const COLORREF kColorComment = RGB(87, 166, 74);
    const COLORREF kColorBuiltin = RGB(78, 201, 176);
    const COLORREF kColorOperator = RGB(212, 212, 212);
    const COLORREF kColorGutter = RGB(60, 63, 65);
    const COLORREF kColorGutterText = RGB(128, 128, 128);
    const COLORREF kColorStatusBar = RGB(37, 37, 38);

    // ── Keyword sets ─────────────────────────────────────────────────────
    const std::unordered_set<std::wstring> &keywords()
    {
        static const std::unordered_set<std::wstring> table{
            L"let", L"show", L"when", L"otherwise", L"repeat", L"true", L"false", L"nothing",
            L"and", L"or", L"not", L"if", L"elif", L"else", L"func", L"return", L"for",
            L"in", L"to", L"step", L"while", L"until", L"forever", L"break", L"continue",
            L"import", L"pass",
        };
        return table;
    }

    const std::unordered_set<std::wstring> &builtins()
    {
        static const std::unordered_set<std::wstring> table{
            L"length", L"text", L"number", L"type_of", L"range", L"push", L"pop",
            L"sort", L"sorted", L"reverse", L"reversed", L"unique", L"flatten",
            L"count", L"sum", L"product", L"average", L"min_of", L"max_of",
            L"contains", L"find", L"slice", L"enumerate", L"zip", L"any", L"all",
            L"join", L"split", L"upper", L"lower", L"trim", L"replace",
            L"starts_with", L"ends_with", L"char_at", L"to_char", L"ord",
            L"abs", L"sqrt", L"floor", L"ceil", L"round", L"pow",
            L"min", L"max", L"random", L"clamp",
            L"input", L"read_file", L"write_file", L"sleep_ms", L"now_ms",
            L"is_number", L"is_text", L"is_list", L"is_nothing", L"assert",
            L"window_open", L"window_should_close", L"window_clear",
            L"window_set_pixel", L"window_fill_rect", L"window_draw_line",
            L"window_present", L"window_close",
        };
        return table;
    }

    // ── Utility functions ────────────────────────────────────────────────
    std::wstring widen(const std::string &text)
    {
        if (text.empty()) return {};
        const int length = MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), nullptr, 0);
        std::wstring result(static_cast<std::size_t>(length), L'\0');
        MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), result.data(), length);
        return result;
    }

    std::string narrow(const std::wstring &text)
    {
        if (text.empty()) return {};
        const int length = WideCharToMultiByte(CP_UTF8, 0, text.data(), static_cast<int>(text.size()),
                                               nullptr, 0, nullptr, nullptr);
        std::string result(static_cast<std::size_t>(length), '\0');
        WideCharToMultiByte(CP_UTF8, 0, text.data(), static_cast<int>(text.size()),
                            result.data(), length, nullptr, nullptr);
        return result;
    }

    std::wstring window_text()
    {
        const int length = GetWindowTextLengthW(g_editor);
        std::wstring text(static_cast<std::size_t>(length) + 1, L'\0');
        const int copied = GetWindowTextW(g_editor, text.data(), length + 1);
        text.resize(static_cast<std::size_t>(copied));
        return text;
    }

    int line_count()
    {
        return static_cast<int>(SendMessageW(g_editor, EM_GETLINECOUNT, 0, 0));
    }

    // ── Status bar ───────────────────────────────────────────────────────
    void update_status_bar()
    {
        if (g_status == nullptr || g_editor == nullptr) return;

        CHARRANGE selection{};
        SendMessageW(g_editor, EM_EXGETSEL, 0, reinterpret_cast<LPARAM>(&selection));
        const LONG line = static_cast<LONG>(SendMessageW(g_editor, EM_EXLINEFROMCHAR, 0, selection.cpMin));
        const LONG line_start = static_cast<LONG>(SendMessageW(g_editor, EM_LINEINDEX, line, 0));
        const LONG column = selection.cpMin - line_start;

        const std::wstring file_name = g_file_path.empty()
                                           ? std::wstring{L"untitled.luma"}
                                           : std::filesystem::path{g_file_path}.filename().wstring();

        std::wstring wrap_mode = g_word_wrap ? L"Wrap" : L"NoWrap";
        std::wstring status = file_name + (g_dirty ? L"  *  " : L"  |  ") + L"Ln " +
                              std::to_wstring(line + 1) + L", Col " + std::to_wstring(column + 1) +
                              L"  |  " + wrap_mode +
                              L"  |  UTF-8  |  Luma 0.5";
        SetWindowTextW(g_status, status.c_str());
    }

    void set_title()
    {
        std::wstring name = g_file_path.empty()
                                ? std::wstring{L"untitled.luma"}
                                : std::filesystem::path{g_file_path}.filename().wstring();
        std::wstring title = name + (g_dirty ? L" *" : L"") + L" - " + kAppTitle;
        SetWindowTextW(g_main_window, title.c_str());
        update_status_bar();
    }

    // ── Syntax highlighting (dark theme) ─────────────────────────────────
    void apply_color(LONG start, LONG stop, COLORREF color)
    {
        CHARRANGE range{start, stop};
        SendMessageW(g_editor, EM_EXSETSEL, 0, reinterpret_cast<LPARAM>(&range));
        CHARFORMAT2W format{};
        format.cbSize = sizeof(format);
        format.dwMask = CFM_COLOR;
        format.crTextColor = color;
        SendMessageW(g_editor, EM_SETCHARFORMAT, SCF_SELECTION, reinterpret_cast<LPARAM>(&format));
    }

    void highlight()
    {
        if (g_highlighting || g_editor == nullptr) return;
        g_highlighting = true;

        const LRESULT old_mask = SendMessageW(g_editor, EM_SETEVENTMASK, 0, 0);
        SendMessageW(g_editor, WM_SETREDRAW, FALSE, 0);
        CHARRANGE saved_selection{};
        SendMessageW(g_editor, EM_EXGETSEL, 0, reinterpret_cast<LPARAM>(&saved_selection));
        POINT saved_scroll{};
        SendMessageW(g_editor, EM_GETSCROLLPOS, 0, reinterpret_cast<LPARAM>(&saved_scroll));

        std::wstring text = window_text();
        text.erase(std::remove(text.begin(), text.end(), L'\n'), text.end());

        // Reset to default foreground
        apply_color(0, static_cast<LONG>(text.size()), kFgDefault);

        std::size_t index = 0;
        while (index < text.size())
        {
            const wchar_t ch = text[index];
            if (ch == L'#')
            {
                std::size_t stop = index;
                while (stop < text.size() && text[stop] != L'\r')
                    ++stop;
                apply_color(static_cast<LONG>(index), static_cast<LONG>(stop), kColorComment);
                index = stop;
            }
            else if (ch == L'"' || ch == L'\'')
            {
                const wchar_t quote = ch;
                std::size_t stop = index + 1;
                while (stop < text.size() && text[stop] != quote && text[stop] != L'\r')
                {
                    if (text[stop] == L'\\') ++stop;
                    ++stop;
                }
                if (stop < text.size() && text[stop] == quote) ++stop;
                apply_color(static_cast<LONG>(index), static_cast<LONG>(stop), kColorString);
                index = stop;
            }
            else if (iswdigit(ch) != 0)
            {
                std::size_t stop = index;
                while (stop < text.size() && (iswdigit(text[stop]) != 0 || text[stop] == L'.' || text[stop] == L'+' || text[stop] == L'-'))
                    ++stop;
                apply_color(static_cast<LONG>(index), static_cast<LONG>(stop), kColorNumber);
                index = stop;
            }
            else if (iswalpha(ch) != 0 || ch == L'_')
            {
                std::size_t stop = index;
                while (stop < text.size() && (iswalnum(text[stop]) != 0 || text[stop] == L'_'))
                    ++stop;
                const std::wstring word = text.substr(index, stop - index);
                if (keywords().count(word) != 0)
                    apply_color(static_cast<LONG>(index), static_cast<LONG>(stop), kColorKeyword);
                else if (builtins().count(word) != 0)
                    apply_color(static_cast<LONG>(index), static_cast<LONG>(stop), kColorBuiltin);
                index = stop;
            }
            else
            {
                ++index;
            }
        }

        SendMessageW(g_editor, EM_EXSETSEL, 0, reinterpret_cast<LPARAM>(&saved_selection));
        SendMessageW(g_editor, EM_SETSCROLLPOS, 0, reinterpret_cast<LPARAM>(&saved_scroll));
        SendMessageW(g_editor, WM_SETREDRAW, TRUE, 0);
        InvalidateRect(g_editor, nullptr, TRUE);
        SendMessageW(g_editor, EM_SETEVENTMASK, 0, old_mask);
        g_highlighting = false;
    }

    // ── File operations ──────────────────────────────────────────────────
    bool save_to(const std::wstring &path)
    {
        const std::string utf8 = narrow(window_text());
        std::ofstream stream{std::filesystem::path{path}, std::ios::binary};
        if (!stream)
        {
            MessageBoxW(g_main_window, (L"Could not save to:\n" + path).c_str(), kAppTitle, MB_OK | MB_ICONERROR);
            return false;
        }
        stream << utf8;
        stream.close();
        g_file_path = path;
        g_dirty = false;
        set_title();
        return true;
    }

    bool save_as()
    {
        wchar_t buffer[MAX_PATH] = L"";
        if (!g_file_path.empty() && g_file_path.size() < MAX_PATH - 1)
            std::copy(g_file_path.begin(), g_file_path.end(), buffer);
        OPENFILENAMEW dialog{};
        dialog.lStructSize = sizeof(dialog);
        dialog.hwndOwner = g_main_window;
        dialog.lpstrFilter = L"Luma programs (*.luma)\0*.luma\0All files (*.*)\0*.*\0";
        dialog.lpstrFile = buffer;
        dialog.nMaxFile = MAX_PATH;
        dialog.lpstrDefExt = L"luma";
        dialog.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
        if (GetSaveFileNameW(&dialog) == FALSE) return false;
        return save_to(buffer);
    }

    bool save()
    {
        if (g_file_path.empty()) return save_as();
        return save_to(g_file_path);
    }

    bool confirm_unsaved()
    {
        if (!g_dirty) return true;
        const int answer = MessageBoxW(g_main_window, L"Save the changes to this file first?", kAppTitle,
                                       MB_YESNOCANCEL | MB_ICONQUESTION);
        if (answer == IDCANCEL) return false;
        if (answer == IDYES) return save();
        return true;
    }

    void load_file(const std::wstring &path)
    {
        std::ifstream stream{std::filesystem::path{path}, std::ios::binary};
        if (!stream)
        {
            MessageBoxW(g_main_window, (L"Could not open:\n" + path).c_str(), kAppTitle, MB_OK | MB_ICONERROR);
            return;
        }
        std::ostringstream contents;
        contents << stream.rdbuf();
        SetWindowTextW(g_editor, widen(contents.str()).c_str());
        g_file_path = path;
        g_dirty = false;
        set_title();
        highlight();
    }

    void open_file_dialog()
    {
        if (!confirm_unsaved()) return;
        wchar_t buffer[MAX_PATH] = L"";
        OPENFILENAMEW dialog{};
        dialog.lStructSize = sizeof(dialog);
        dialog.hwndOwner = g_main_window;
        dialog.lpstrFilter = L"Luma programs (*.luma)\0*.luma\0All files (*.*)\0*.*\0";
        dialog.lpstrFile = buffer;
        dialog.nMaxFile = MAX_PATH;
        dialog.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
        if (GetOpenFileNameW(&dialog) == FALSE) return;
        load_file(buffer);
    }

    void new_file()
    {
        if (!confirm_unsaved()) return;
        SetWindowTextW(g_editor, L"");
        g_file_path.clear();
        g_dirty = false;
        set_title();
    }

    // ── Find / Replace (modeless dialog) ─────────────────────────────────
    // Command IDs for find dialog buttons
    constexpr int FIND_BTN_FIND   = 5001;
    constexpr int FIND_BTN_REPLACE = 5002;
    constexpr int FIND_BTN_REPLACEALL = 5003;
    constexpr int FIND_CHK_WHOLE  = 5004;

    void close_find_dialog()
    {
        if (g_find_dialog != nullptr && IsWindow(g_find_dialog))
        {
            HWND to_destroy = g_find_dialog;
            g_find_dialog = nullptr;
            g_find_edit = nullptr;
            g_replace_edit = nullptr;
            g_replace_check = nullptr;
            DestroyWindow(to_destroy);
            SetFocus(g_editor);
        }
    }

    void do_find_replace(bool show_replace)
    {
        if (g_find_dialog != nullptr)
        {
            SetFocus(g_find_edit);
            return;
        }

        // Pre-fill with current selection if any
        CHARRANGE sel{};
        SendMessageW(g_editor, EM_EXGETSEL, 0, reinterpret_cast<LPARAM>(&sel));
        std::wstring prefill;
        if (sel.cpMin != sel.cpMax)
        {
            std::wstring content = window_text();
            prefill = content.substr(static_cast<std::size_t>(sel.cpMin),
                                     static_cast<std::size_t>(sel.cpMax - sel.cpMin));
        }

        g_find_dialog = CreateWindowExW(0, kFindClass, L"Find & Replace",
                                        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU,
                                        CW_USEDEFAULT, CW_USEDEFAULT, 460, show_replace ? 170 : 115,
                                        g_main_window, nullptr, GetModuleHandleW(nullptr), nullptr);

        CreateWindowExW(0, L"STATIC", L"Find:", WS_CHILD | WS_VISIBLE,
                        10, 14, 40, 20, g_find_dialog, nullptr, nullptr, nullptr);
        g_find_edit = CreateWindowExW(0, L"EDIT", L"",
                                      WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL,
                                      55, 10, 300, 24, g_find_dialog, nullptr, nullptr, nullptr);
        if (!prefill.empty())
            SetWindowTextW(g_find_edit, prefill.c_str());

        HWND btn_find = CreateWindowExW(0, L"BUTTON", L"Find Next",
                                        WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
                                        365, 10, 80, 24, g_find_dialog,
                                        reinterpret_cast<HMENU>(FIND_BTN_FIND), nullptr, nullptr);

        if (show_replace)
        {
            CreateWindowExW(0, L"STATIC", L"Replace:", WS_CHILD | WS_VISIBLE,
                            10, 50, 45, 20, g_find_dialog, nullptr, nullptr, nullptr);
            g_replace_edit = CreateWindowExW(0, L"EDIT", L"",
                                             WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL,
                                             55, 46, 300, 24, g_find_dialog, nullptr, nullptr, nullptr);
            CreateWindowExW(0, L"BUTTON", L"Replace",
                            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                            365, 46, 80, 24, g_find_dialog,
                            reinterpret_cast<HMENU>(FIND_BTN_REPLACE), nullptr, nullptr);
            CreateWindowExW(0, L"BUTTON", L"Replace All",
                            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                            365, 78, 80, 24, g_find_dialog,
                            reinterpret_cast<HMENU>(FIND_BTN_REPLACEALL), nullptr, nullptr);
        }

        g_replace_check = CreateWindowExW(0, L"BUTTON", L"Match whole word only",
                                          WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
                                          10, show_replace ? 80 : 44, 200, 20, g_find_dialog,
                                          reinterpret_cast<HMENU>(FIND_CHK_WHOLE), nullptr, nullptr);

        SetClassLongPtrW(g_find_dialog, GCLP_HBRBACKGROUND,
                         reinterpret_cast<LONG_PTR>(CreateSolidBrush(RGB(37, 37, 38))));

        ShowWindow(g_find_dialog, SW_SHOW);
        SetFocus(g_find_edit);
        // No blocking message loop — commands handled by main WndProc
    }

    void do_find_next()
    {
        if (g_find_edit == nullptr || !IsWindow(g_find_edit)) return;
        wchar_t search_text[512]{};
        GetWindowTextW(g_find_edit, search_text, 512);
        if (wcslen(search_text) == 0) return;

        CHARRANGE sel{};
        SendMessageW(g_editor, EM_EXGETSEL, 0, reinterpret_cast<LPARAM>(&sel));
        LONG start = sel.cpMax;
        std::wstring content = window_text();
        std::wstring needle(search_text);

        std::wstring content_from = content.substr(static_cast<std::size_t>(start));
        std::wstring lower_content = content_from;
        std::wstring lower_needle = needle;
        std::transform(lower_content.begin(), lower_content.end(), lower_content.begin(), ::towlower);
        std::transform(lower_needle.begin(), lower_needle.end(), lower_needle.begin(), ::towlower);

        auto pos = lower_content.find(lower_needle);
        if (pos == std::wstring::npos)
        {
            lower_content = content;
            std::transform(lower_content.begin(), lower_content.end(), lower_content.begin(), ::towlower);
            pos = lower_content.find(lower_needle);
            start = 0;
        }
        if (pos != std::wstring::npos)
        {
            LONG found_start = start + static_cast<LONG>(pos);
            LONG found_end = found_start + static_cast<LONG>(needle.size());
            CHARRANGE new_sel{found_start, found_end};
            SendMessageW(g_editor, EM_EXSETSEL, 0, reinterpret_cast<LPARAM>(&new_sel));
            SendMessageW(g_editor, EM_SCROLLCARET, 0, 0);
        }
        else
        {
            MessageBoxW(g_find_dialog, L"Text not found.", kAppTitle, MB_OK | MB_ICONINFORMATION);
        }
    }

    void do_replace_one()
    {
        if (g_find_edit == nullptr || !IsWindow(g_find_edit)) return;
        if (g_replace_edit == nullptr || !IsWindow(g_replace_edit)) return;
        wchar_t search_text[512]{}, replace_text[512]{};
        GetWindowTextW(g_find_edit, search_text, 512);
        GetWindowTextW(g_replace_edit, replace_text, 512);
        CHARRANGE sel{};
        SendMessageW(g_editor, EM_EXGETSEL, 0, reinterpret_cast<LPARAM>(&sel));
        if (sel.cpMin != sel.cpMax)
        {
            std::wstring content = window_text();
            std::wstring sel_text = content.substr(static_cast<std::size_t>(sel.cpMin),
                                                   static_cast<std::size_t>(sel.cpMax - sel.cpMin));
            std::wstring lower_sel = sel_text;
            std::wstring lower_search = search_text;
            std::transform(lower_sel.begin(), lower_sel.end(), lower_sel.begin(), ::towlower);
            std::transform(lower_search.begin(), lower_search.end(), lower_search.begin(), ::towlower);
            if (lower_sel == lower_search)
            {
                SendMessageW(g_editor, EM_REPLACESEL, TRUE,
                             reinterpret_cast<LPARAM>(replace_text));
            }
        }
        do_find_next();
    }

    void do_replace_all()
    {
        if (g_find_edit == nullptr || !IsWindow(g_find_edit)) return;
        if (g_replace_edit == nullptr || !IsWindow(g_replace_edit)) return;
        wchar_t search_text[512]{}, replace_text[512]{};
        GetWindowTextW(g_find_edit, search_text, 512);
        GetWindowTextW(g_replace_edit, replace_text, 512);
        if (wcslen(search_text) == 0) return;
        std::wstring content = window_text();
        std::wstring needle(search_text);
        std::wstring replacement(replace_text);
        std::wstring lower_content = content;
        std::wstring lower_needle = needle;
        std::transform(lower_content.begin(), lower_content.end(), lower_content.begin(), ::towlower);
        std::transform(lower_needle.begin(), lower_needle.end(), lower_needle.begin(), ::towlower);

        int count = 0;
        std::wstring result;
        std::size_t last = 0;
        std::size_t pos = 0;
        while ((pos = lower_content.find(lower_needle, last)) != std::wstring::npos)
        {
            result += content.substr(last, pos - last);
            result += replacement;
            last = pos + needle.size();
            ++count;
        }
        result += content.substr(last);
        if (count > 0)
        {
            g_highlighting = true;
            SetWindowTextW(g_editor, result.c_str());
            g_highlighting = false;
            std::wstring msg = std::to_wstring(count) + L" occurrence(s) replaced.";
            MessageBoxW(g_find_dialog, msg.c_str(), kAppTitle, MB_OK | MB_ICONINFORMATION);
        }
        else
        {
            MessageBoxW(g_find_dialog, L"Text not found.", kAppTitle, MB_OK | MB_ICONINFORMATION);
        }
    }

    // ── Goto Line dialog ─────────────────────────────────────────────────
    void goto_line()
    {
        HWND dlg = CreateWindowExW(0, kFindClass, L"Go to Line",
                                   WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU,
                                   CW_USEDEFAULT, CW_USEDEFAULT, 280, 120,
                                   g_main_window, nullptr, GetModuleHandleW(nullptr), nullptr);
        SetClassLongPtrW(dlg, GCLP_HBRBACKGROUND, reinterpret_cast<LONG_PTR>(CreateSolidBrush(RGB(37, 37, 38))));

        CreateWindowExW(0, L"STATIC", L"Line number:", WS_CHILD | WS_VISIBLE,
                        10, 14, 250, 20, dlg, nullptr, nullptr, nullptr);
        HWND edit = CreateWindowExW(0, L"EDIT", L"",
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL | ES_NUMBER,
                                    10, 38, 250, 22, dlg, nullptr, nullptr, nullptr);
        HWND ok_btn = CreateWindowExW(0, L"BUTTON", L"Go",
                                      WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
                                      100, 70, 70, 24, dlg,
                                      reinterpret_cast<HMENU>(IDOK), nullptr, nullptr);
        HWND cancel_btn = CreateWindowExW(0, L"BUTTON", L"Cancel",
                                          WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                                          180, 70, 70, 24, dlg,
                                          reinterpret_cast<HMENU>(IDCANCEL), nullptr, nullptr);

        ShowWindow(dlg, SW_SHOW);
        SetFocus(edit);

        MSG msg{};
        bool done = false;
        while (!done && GetMessageW(&msg, nullptr, 0, 0) > 0)
        {
            if (msg.message == WM_COMMAND)
            {
                WORD cmd = LOWORD(msg.wParam);
                if (cmd == IDOK)
                {
                    wchar_t num[32]{};
                    GetWindowTextW(edit, num, 32);
                    int line = _wtoi(num);
                    if (line >= 1 && line <= line_count())
                    {
                        LONG pos = static_cast<LONG>(SendMessageW(g_editor, EM_LINEINDEX, line - 1, 0));
                        CHARRANGE sel{pos, pos};
                        SendMessageW(g_editor, EM_EXSETSEL, 0, reinterpret_cast<LPARAM>(&sel));
                        SendMessageW(g_editor, EM_SCROLLCARET, 0, 0);
                        SetFocus(g_editor);
                    }
                    done = true;
                }
                else if (cmd == IDCANCEL)
                {
                    SetFocus(g_editor);
                    done = true;
                }
            }
            if (msg.message == WM_CLOSE && msg.hwnd == dlg)
            {
                SetFocus(g_editor);
                done = true;
            }
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        DestroyWindow(dlg);
    }

    // ── Run / Build ──────────────────────────────────────────────────────
    std::wstring find_luma()
    {
        wchar_t module_path[MAX_PATH] = L"";
        GetModuleFileNameW(nullptr, module_path, MAX_PATH);
        const std::filesystem::path directory = std::filesystem::path{module_path}.parent_path();
        std::error_code ignored;
        const std::filesystem::path candidate = directory / L"luma.exe";
        if (std::filesystem::exists(candidate, ignored))
            return candidate.wstring();
        return L"luma";
    }

    void run_program(bool build)
    {
        if (g_file_path.empty() || g_dirty)
        {
            if (!save()) return;
        }
        const std::wstring luma = find_luma();
        const std::wstring verb = build ? L"build" : L"run";
        const std::wstring working_directory = std::filesystem::path{g_file_path}.parent_path().wstring();
        // Write a temp batch file to avoid quoting issues
        std::wstring bat_path = std::filesystem::temp_directory_path().wstring() + L"\\luma_run.bat";
        {
            std::ofstream bat(narrow(bat_path));
            bat << "@echo off\n";
            bat << "cd /d \"" << narrow(working_directory) << "\"\n";
            bat << "\"" << narrow(luma) << "\" " << narrow(verb) << " \"" << narrow(g_file_path) << "\"\n";
            bat << "echo.\n";
            bat << "echo Press any key to close...\n";
            bat << "pause >nul\n";
        }
        std::wstring command = L"cmd /k \"" + bat_path + L"\"";

        if (build)
            g_last_built_exe = std::filesystem::path{g_file_path}.replace_extension(L".exe").wstring();

        STARTUPINFOW startup{};
        startup.cb = sizeof(startup);
        PROCESS_INFORMATION process{};
        std::vector<wchar_t> mutable_command(command.begin(), command.end());
        mutable_command.push_back(L'\0');
        if (CreateProcessW(nullptr, mutable_command.data(), nullptr, nullptr, FALSE, CREATE_NEW_CONSOLE, nullptr,
                           working_directory.empty() ? nullptr : working_directory.c_str(), &startup, &process))
        {
            CloseHandle(process.hProcess);
            CloseHandle(process.hThread);
        }
        else
        {
            std::wstring msg = L"Could not start luma.exe.\n";
            if (build) msg += L"Make sure both luma.exe and luma_vm.exe are installed.\n";
            msg += L"Install Luma or put luma.exe next to this editor.";
            MessageBoxW(g_main_window, msg.c_str(), kAppTitle, MB_OK | MB_ICONERROR);
        }
    }

    void run_last()
    {
        if (!g_last_built_exe.empty() && std::filesystem::exists(g_last_built_exe))
        {
            std::wstring bat_path = std::filesystem::temp_directory_path().wstring() + L"\\luma_run.bat";
            {
                std::ofstream bat(narrow(bat_path));
                bat << "@echo off\n";
                bat << "cd /d \"" << narrow(std::filesystem::path{g_last_built_exe}.parent_path().wstring()) << "\"\n";
                bat << "\"" << narrow(g_last_built_exe) << "\"\n";
                bat << "echo.\n";
                bat << "echo Press any key to close...\n";
                bat << "pause >nul\n";
            }
            std::wstring command = L"cmd /k \"" + bat_path + L"\"";
            const std::wstring working_directory = std::filesystem::path{g_last_built_exe}.parent_path().wstring();
            STARTUPINFOW startup{};
            startup.cb = sizeof(startup);
            PROCESS_INFORMATION process{};
            std::vector<wchar_t> mutable_command(command.begin(), command.end());
            mutable_command.push_back(L'\0');
            if (CreateProcessW(nullptr, mutable_command.data(), nullptr, nullptr, FALSE, CREATE_NEW_CONSOLE, nullptr,
                               working_directory.empty() ? nullptr : working_directory.c_str(), &startup, &process))
            {
                CloseHandle(process.hProcess);
                CloseHandle(process.hThread);
            }
        }
        else
        {
            run_program(true);
        }
    }

    // ── Editor subclass (Tab, Enter, shortcuts) ──────────────────────────
    LRESULT CALLBACK editor_subclass(HWND window, UINT message, WPARAM w_param, LPARAM l_param, UINT_PTR, DWORD_PTR)
    {
        if (message == WM_CHAR && w_param == L'\t')
        {
            SendMessageW(window, EM_REPLACESEL, TRUE, reinterpret_cast<LPARAM>(L"    "));
            return 0;
        }
        if (message == WM_CHAR && w_param == L'\r')
        {
            CHARRANGE selection{};
            SendMessageW(window, EM_EXGETSEL, 0, reinterpret_cast<LPARAM>(&selection));
            const LONG line = static_cast<LONG>(SendMessageW(window, EM_EXLINEFROMCHAR, 0, selection.cpMin));
            const LONG line_start = static_cast<LONG>(SendMessageW(window, EM_LINEINDEX, line, 0));

            wchar_t buffer[1024];
            reinterpret_cast<WORD *>(buffer)[0] = 1022;
            const LONG copied = static_cast<LONG>(SendMessageW(window, EM_GETLINE, line, reinterpret_cast<LPARAM>(buffer)));
            std::wstring line_text(buffer, buffer + copied);

            const LONG caret_column = selection.cpMin - line_start;
            if (caret_column >= 0 && caret_column < static_cast<LONG>(line_text.size()))
                line_text.resize(static_cast<std::size_t>(caret_column));

            std::wstring indent;
            for (const wchar_t ch : line_text)
            {
                if (ch != L' ') break;
                indent += L' ';
            }
            std::wstring trimmed = line_text;
            while (!trimmed.empty() && iswspace(trimmed.back()) != 0)
                trimmed.pop_back();
            if (!trimmed.empty() && trimmed.back() == L':')
                indent += L"    ";

            const std::wstring replacement = L"\r\n" + indent;
            SendMessageW(window, EM_REPLACESEL, TRUE, reinterpret_cast<LPARAM>(replacement.c_str()));
            return 0;
        }
        return DefSubclassProc(window, message, w_param, l_param);
    }

    // ── Create controls ──────────────────────────────────────────────────
    void create_editor_control(HWND parent)
    {
        LoadLibraryW(L"Msftedit.dll");
        g_editor = CreateWindowExW(0, MSFTEDIT_CLASS, L"",
                                   WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL | ES_MULTILINE |
                                       ES_AUTOVSCROLL | ES_AUTOHSCROLL | ES_NOHIDESEL | ES_WANTRETURN,
                                   0, 0, 100, 100, parent, reinterpret_cast<HMENU>(static_cast<UINT_PTR>(kEditorId)),
                                   GetModuleHandleW(nullptr), nullptr);

        CHARFORMAT2W format{};
        format.cbSize = sizeof(format);
        format.dwMask = CFM_FACE | CFM_SIZE | CFM_COLOR;
        {
            const wchar_t face[] = L"Consolas";
            std::copy(std::begin(face), std::end(face), format.szFaceName);
        }
        format.yHeight = 220; // 11pt
        format.crTextColor = kFgDefault;
        SendMessageW(g_editor, EM_SETCHARFORMAT, SCF_ALL, reinterpret_cast<LPARAM>(&format));

        // Dark background
        SendMessageW(g_editor, EM_SETBKGNDCOLOR, 0, kBgDark);

        SendMessageW(g_editor, EM_SETEVENTMASK, 0, ENM_CHANGE | ENM_SELCHANGE);
        SetWindowSubclass(g_editor, editor_subclass, 1, 0);
    }

    void create_status_bar(HWND parent)
    {
        g_status = CreateWindowExW(0, STATUSCLASSNAMEW, L"", WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP,
                                  0, 0, 0, 0, parent, reinterpret_cast<HMENU>(static_cast<UINT_PTR>(kStatusId)),
                                  GetModuleHandleW(nullptr), nullptr);
        update_status_bar();
    }

    void layout_children(LPARAM size_param)
    {
        const int width = LOWORD(size_param);
        const int height = HIWORD(size_param);
        int status_height = 0;

        if (g_status != nullptr)
        {
            SendMessageW(g_status, WM_SIZE, 0, 0);
            RECT status_rect{};
            GetWindowRect(g_status, &status_rect);
            status_height = status_rect.bottom - status_rect.top;
        }
        if (g_editor != nullptr)
            MoveWindow(g_editor, 0, 0, width, std::max(0, height - status_height), TRUE);
    }

    // ── Menu bar ─────────────────────────────────────────────────────────
    HMENU build_menu()
    {
        HMENU bar = CreateMenu();

        // File
        HMENU file_menu = CreatePopupMenu();
        AppendMenuW(file_menu, MF_STRING, ID_FILE_NEW, L"&New\tCtrl+N");
        AppendMenuW(file_menu, MF_STRING, ID_FILE_OPEN, L"&Open...\tCtrl+O");
        AppendMenuW(file_menu, MF_STRING, ID_FILE_SAVE, L"&Save\tCtrl+S");
        AppendMenuW(file_menu, MF_STRING, ID_FILE_SAVEAS, L"Save &As...");
        AppendMenuW(file_menu, MF_SEPARATOR, 0, nullptr);
        AppendMenuW(file_menu, MF_STRING, ID_FILE_EXIT, L"E&xit");
        AppendMenuW(bar, MF_POPUP, reinterpret_cast<UINT_PTR>(file_menu), L"&File");

        // Edit
        HMENU edit_menu = CreatePopupMenu();
        AppendMenuW(edit_menu, MF_STRING, ID_EDIT_UNDO, L"&Undo\tCtrl+Z");
        AppendMenuW(edit_menu, MF_STRING, ID_EDIT_REDO, L"&Redo\tCtrl+Y");
        AppendMenuW(edit_menu, MF_SEPARATOR, 0, nullptr);
        AppendMenuW(edit_menu, MF_STRING, ID_EDIT_FIND, L"&Find...\tCtrl+F");
        AppendMenuW(edit_menu, MF_STRING, ID_EDIT_REPLACE, L"Replace...\tCtrl+H");
        AppendMenuW(edit_menu, MF_SEPARATOR, 0, nullptr);
        AppendMenuW(edit_menu, MF_STRING, ID_EDIT_GOTOLINE, L"&Go to Line...\tCtrl+G");
        AppendMenuW(edit_menu, MF_SEPARATOR, 0, nullptr);
        AppendMenuW(edit_menu, MF_STRING, ID_EDIT_WORDWRAP, L"Word &Wrap");
        AppendMenuW(bar, MF_POPUP, reinterpret_cast<UINT_PTR>(edit_menu), L"&Edit");

        // Run
        HMENU run_menu = CreatePopupMenu();
        AppendMenuW(run_menu, MF_STRING, ID_RUN_RUN, L"Run on &VM\tF5");
        AppendMenuW(run_menu, MF_STRING, ID_RUN_BUILD, L"Build &standalone EXE\tF6");
        AppendMenuW(run_menu, MF_STRING, ID_RUN_LAST, L"Run &last built\tF7");
        AppendMenuW(bar, MF_POPUP, reinterpret_cast<UINT_PTR>(run_menu), L"&Run");

        // Help
        HMENU help_menu = CreatePopupMenu();
        AppendMenuW(help_menu, MF_STRING, ID_HELP_ABOUT, L"&About Luma Editor");
        AppendMenuW(bar, MF_POPUP, reinterpret_cast<UINT_PTR>(help_menu), L"&Help");

        return bar;
    }

    // ── Window procedure ─────────────────────────────────────────────────
    LRESULT CALLBACK window_procedure(HWND window, UINT message, WPARAM w_param, LPARAM l_param)
    {
        switch (message)
        {
        case WM_CREATE:
            g_main_window = window;
            create_editor_control(window);
            create_status_bar(window);
            SetTimer(window, TIMER_AUTOSAVE, 60000, nullptr); // Auto-save every 60s
            return 0;
        case WM_SIZE:
            layout_children(l_param);
            return 0;
        case WM_SETFOCUS:
            SetFocus(g_editor);
            return 0;
        case WM_COMMAND:
            if (HIWORD(w_param) == EN_CHANGE && LOWORD(w_param) == kEditorId)
            {
                if (!g_highlighting)
                {
                    if (!g_dirty)
                    {
                        g_dirty = true;
                        set_title();
                    }
                    // Debounce: wait 300ms after last keystroke before highlighting
                    KillTimer(window, TIMER_HIGHLIGHT);
                    SetTimer(window, TIMER_HIGHLIGHT, 300, nullptr);
                }
                return 0;
            }
            switch (LOWORD(w_param))
            {
            case ID_FILE_NEW:
                new_file();
                return 0;
            case ID_FILE_OPEN:
                open_file_dialog();
                return 0;
            case ID_FILE_SAVE:
                save();
                return 0;
            case ID_FILE_SAVEAS:
                save_as();
                return 0;
            case ID_FILE_EXIT:
                PostMessageW(window, WM_CLOSE, 0, 0);
                return 0;
            case ID_EDIT_UNDO:
                SendMessageW(g_editor, EM_UNDO, 0, 0);
                return 0;
            case ID_EDIT_REDO:
                SendMessageW(g_editor, EM_REDO, 0, 0);
                return 0;
            case ID_EDIT_FIND:
                do_find_replace(false);
                return 0;
            case ID_EDIT_REPLACE:
                do_find_replace(true);
                return 0;
            case ID_EDIT_GOTOLINE:
                goto_line();
                return 0;
            case ID_EDIT_WORDWRAP:
                g_word_wrap = !g_word_wrap;
                {
                    // Toggle word wrap via extended style
                    LONG style = static_cast<LONG>(GetWindowLongPtrW(g_editor, GWL_STYLE));
                    if (g_word_wrap)
                        style &= ~ES_AUTOHSCROLL;
                    else
                        style |= ES_AUTOHSCROLL;
                    SetWindowLongPtrW(g_editor, GWL_STYLE, style);
                    SetWindowPos(g_editor, nullptr, 0, 0, 0, 0,
                                 SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
                    update_status_bar();
                }
                return 0;
            case ID_RUN_RUN:
                run_program(false);
                return 0;
            case ID_RUN_BUILD:
                run_program(true);
                return 0;
            case ID_RUN_LAST:
                run_last();
                return 0;
            case ID_HELP_ABOUT:
                MessageBoxW(window,
                            L"Luma Editor v0.5\n\n"
                            L"A tiny editor made only for the Luma language.\n\n"
                            L"F5  Run on bytecode VM\n"
                            L"F6  Build standalone .exe (no C++ needed)\n"
                            L"F7  Run last built program\n"
                            L"Ctrl+F  Find  |  Ctrl+H  Replace\n"
                            L"Ctrl+G  Go to line\n"
                            L"Ctrl+S  Save  |  Auto-save enabled\n"
                            L"Tab inserts 4 spaces, Enter auto-indents\n\n"
                            L"Dark theme with syntax highlighting.",
                            kAppTitle, MB_OK | MB_ICONINFORMATION);
                return 0;
            // Find dialog buttons (modeless)
            case FIND_BTN_FIND:
                do_find_next();
                return 0;
            case FIND_BTN_REPLACE:
                do_replace_one();
                return 0;
            case FIND_BTN_REPLACEALL:
                do_replace_all();
                return 0;
            case FIND_CHK_WHOLE:
                g_find_whole = (SendMessageW(g_replace_check, BM_GETCHECK, 0, 0) == BST_CHECKED);
                return 0;
            default:
                break;
            }
            break;
        case WM_TIMER:
            if (w_param == TIMER_HIGHLIGHT)
            {
                KillTimer(window, TIMER_HIGHLIGHT);
                highlight();
            }
            else if (w_param == TIMER_AUTOSAVE)
            {
                if (g_dirty && !g_file_path.empty())
                    save_to(g_file_path);
            }
            return 0;
        case WM_NOTIFY:
            if (const auto *header = reinterpret_cast<NMHDR *>(l_param);
                header != nullptr && header->hwndFrom == g_editor && header->code == EN_SELCHANGE)
            {
                update_status_bar();
                return 0;
            }
            break;
        case WM_CLOSE:
            if (confirm_unsaved())
            {
                close_find_dialog();
                DestroyWindow(window);
            }
            return 0;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        default:
            break;
        }
        return DefWindowProcW(window, message, w_param, l_param);
    }

}

int WINAPI WinMain(HINSTANCE instance, HINSTANCE, LPSTR, int show_command)
{
    SetProcessDPIAware();
    INITCOMMONCONTROLSEX controls{sizeof(INITCOMMONCONTROLSEX), ICC_STANDARD_CLASSES | ICC_BAR_CLASSES};
    InitCommonControlsEx(&controls);

    // Find dialog WndProc — intercept WM_CLOSE to clean up globals
    // (defined here as a static lambda that can convert to function pointer)

    // Register find dialog class
    WNDCLASSW find_class{};
    find_class.lpfnWndProc = DefWindowProcW;
    find_class.hInstance = instance;
    find_class.hInstance = instance;
    find_class.lpszClassName = kFindClass;
    find_class.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    find_class.hbrBackground = reinterpret_cast<HBRUSH>(CreateSolidBrush(RGB(37, 37, 38)));
    RegisterClassW(&find_class);

    // Register main window class
    WNDCLASSW window_class{};
    window_class.lpfnWndProc = window_procedure;
    window_class.hInstance = instance;
    window_class.lpszClassName = kWindowClass;
    window_class.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    window_class.hbrBackground = reinterpret_cast<HBRUSH>(CreateSolidBrush(kBgDark));
    window_class.hIcon = LoadIconW(nullptr, IDI_APPLICATION);  // fallback
    RegisterClassW(&window_class);

    HWND window = CreateWindowExW(0, kWindowClass, kAppTitle, WS_OVERLAPPEDWINDOW,
                                  CW_USEDEFAULT, CW_USEDEFAULT, 1000, 700,
                                  nullptr, build_menu(), instance, nullptr);
    // Load icon from luma-edit.exe itself (embedded via resource), or extract from exe
    {
        HICON icon = ExtractIconW(instance, L"luma-edit.exe", 0);
        if (icon == nullptr || icon == reinterpret_cast<HICON>(1))
            icon = ExtractIconW(instance, L"luma.exe", 0);
        if (icon != nullptr && icon != reinterpret_cast<HICON>(1))
        {
            SendMessageW(window, WM_SETICON, ICON_BIG, reinterpret_cast<LPARAM>(icon));
            SendMessageW(window, WM_SETICON, ICON_SMALL, reinterpret_cast<LPARAM>(icon));
        }
    }
    ShowWindow(window, show_command);
    set_title();

    // Open file from command line
    int argument_count = 0;
    LPWSTR *arguments = CommandLineToArgvW(GetCommandLineW(), &argument_count);
    if (arguments != nullptr)
    {
        if (argument_count > 1)
            load_file(arguments[1]);
        LocalFree(arguments);
    }

    const ACCEL accelerators[] = {
        {FCONTROL | FVIRTKEY, 'N', ID_FILE_NEW},
        {FCONTROL | FVIRTKEY, 'O', ID_FILE_OPEN},
        {FCONTROL | FVIRTKEY, 'S', ID_FILE_SAVE},
        {FCONTROL | FVIRTKEY, 'Z', ID_EDIT_UNDO},
        {FCONTROL | FVIRTKEY, 'Y', ID_EDIT_REDO},
        {FCONTROL | FVIRTKEY, 'F', ID_EDIT_FIND},
        {FCONTROL | FVIRTKEY, 'H', ID_EDIT_REPLACE},
        {FCONTROL | FVIRTKEY, 'G', ID_EDIT_GOTOLINE},
        {FVIRTKEY, VK_F5, ID_RUN_RUN},
        {FVIRTKEY, VK_F6, ID_RUN_BUILD},
        {FVIRTKEY, VK_F7, ID_RUN_LAST},
    };
    HACCEL accelerator_table = CreateAcceleratorTableW(const_cast<ACCEL *>(accelerators),
                                                       static_cast<int>(sizeof(accelerators) / sizeof(accelerators[0])));

    MSG message{};
    while (GetMessageW(&message, nullptr, 0, 0) > 0)
    {
        if (TranslateAcceleratorW(window, accelerator_table, &message) != 0)
            continue;
        TranslateMessage(&message);
        DispatchMessageW(&message);
    }
    DestroyAcceleratorTable(accelerator_table);
    return static_cast<int>(message.wParam);
}
