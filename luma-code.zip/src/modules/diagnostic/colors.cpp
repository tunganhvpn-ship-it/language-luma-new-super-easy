#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor diagnostic_colors() { return {"diagnostic", "colors", "Defines terminal color policy"}; }
}