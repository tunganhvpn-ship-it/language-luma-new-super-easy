#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor diagnostic_codes() { return {"diagnostic", "codes", "Reserves stable diagnostic identifiers"}; }
}