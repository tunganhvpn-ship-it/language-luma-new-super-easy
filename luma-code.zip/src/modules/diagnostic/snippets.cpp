#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor diagnostic_snippets() { return {"diagnostic", "snippets", "Extracts focused source snippets"}; }
}