#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor diagnostic_reporter() { return {"diagnostic", "reporter", "Coordinates diagnostic delivery"}; }
}