#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor diagnostic_context() { return {"diagnostic", "context", "Carries contextual error information"}; }
}