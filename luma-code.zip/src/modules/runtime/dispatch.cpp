#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor runtime_dispatch() { return {"runtime", "dispatch", "Reserves dynamic dispatch protocol"}; }
}