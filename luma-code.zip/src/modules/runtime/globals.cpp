#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor runtime_globals() { return {"runtime", "globals", "Defines global binding storage"}; }
}