#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor runtime_closures() { return {"runtime", "closures", "Reserves lexical closure ownership"}; }
}