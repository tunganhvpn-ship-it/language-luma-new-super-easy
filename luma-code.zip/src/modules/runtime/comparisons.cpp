#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor runtime_comparisons() { return {"runtime", "comparisons", "Defines comparison execution semantics"}; }
}