#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor runtime_internals() { return {"runtime", "internals", "Defines VM internal state boundaries"}; }
}