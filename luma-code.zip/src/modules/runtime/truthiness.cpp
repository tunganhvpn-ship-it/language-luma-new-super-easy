#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor runtime_truthiness() { return {"runtime", "truthiness", "Defines boolean coercion semantics"}; }
}