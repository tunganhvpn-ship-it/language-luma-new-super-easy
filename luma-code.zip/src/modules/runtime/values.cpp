#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor runtime_values() { return {"runtime", "values", "Defines runtime value representation"}; }
}