#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor runtime_stack() { return {"runtime", "stack", "Owns evaluation stack conventions"}; }
}