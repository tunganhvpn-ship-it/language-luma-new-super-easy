#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor runtime_call_frames() { return {"runtime", "call_frames", "Reserves function call frame layout"}; }
}