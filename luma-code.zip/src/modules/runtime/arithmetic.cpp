#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor runtime_arithmetic() { return {"runtime", "arithmetic", "Defines numeric execution semantics"}; }
}