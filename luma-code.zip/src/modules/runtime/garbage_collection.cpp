#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor runtime_garbage_collection() { return {"runtime", "garbage_collection", "Reserves managed object collection"}; }
}