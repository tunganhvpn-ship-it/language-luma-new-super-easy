#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor stdlib_system() { return {"stdlib", "system", "Reserves operating-system integration"}; }
}