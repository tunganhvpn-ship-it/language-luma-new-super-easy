#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor stdlib_lists() { return {"stdlib", "lists", "Reserves list processing functions"}; }
}