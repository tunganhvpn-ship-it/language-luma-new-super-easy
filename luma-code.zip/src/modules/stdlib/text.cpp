#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor stdlib_text() { return {"stdlib", "text", "Reserves text utility functions"}; }
}