#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor stdlib_io() { return {"stdlib", "io", "Reserves terminal and file I/O functions"}; }
}