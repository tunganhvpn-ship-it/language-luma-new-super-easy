#include "luma/modules/catalog.hpp"

namespace luma
{

    const std::vector<ModuleDescriptor> &module_catalog()
    {
        static const std::vector<ModuleDescriptor> modules{
#define LUMA_COLLECT_DESCRIPTOR(area, name) modules::area##_##name(),
            LUMA_DESCRIPTOR_FUNCTIONS(LUMA_COLLECT_DESCRIPTOR)
#undef LUMA_COLLECT_DESCRIPTOR
        };
        return modules;
    }

}