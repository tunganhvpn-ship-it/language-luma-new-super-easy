#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor core_utf8() { return {"core", "utf8", "Owns UTF-8 boundary validation"}; }
}