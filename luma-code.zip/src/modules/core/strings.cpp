#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor core_strings() { return {"core", "strings", "Defines shared string handling policy"}; }
}