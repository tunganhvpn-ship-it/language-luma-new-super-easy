#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor core_tracing() { return {"core", "tracing", "Defines structured trace extension points"}; }
}