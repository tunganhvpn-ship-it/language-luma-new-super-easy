#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor core_source_locations() { return {"core", "source_locations", "Tracks user-facing source positions"}; }
}