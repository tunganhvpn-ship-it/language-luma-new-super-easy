#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor core_handles() { return {"core", "handles", "Defines opaque resource handle rules"}; }
}