#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor core_identifiers() { return {"core", "identifiers", "Standardizes stable internal identifiers"}; }
}