#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor core_clocks() { return {"core", "clocks", "Provides monotonic timing contracts"}; }
}