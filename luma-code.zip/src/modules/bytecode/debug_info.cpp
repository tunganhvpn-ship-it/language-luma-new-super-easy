#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor bytecode_debug_info() { return {"bytecode", "debug_info", "Reserves instruction-to-source mapping"}; }
}