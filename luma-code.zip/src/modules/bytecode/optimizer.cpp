#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor bytecode_optimizer() { return {"bytecode", "optimizer", "Reserves bytecode optimization passes"}; }
}