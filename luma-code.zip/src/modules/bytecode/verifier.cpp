#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor bytecode_verifier() { return {"bytecode", "verifier", "Reserves instruction safety verification"}; }
}