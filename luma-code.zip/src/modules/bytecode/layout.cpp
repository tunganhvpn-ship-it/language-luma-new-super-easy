#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor bytecode_layout() { return {"bytecode", "layout", "Defines instruction storage layout"}; }
}