#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor bytecode_emitter() { return {"bytecode", "emitter", "Emits VM instructions from semantic nodes"}; }
}