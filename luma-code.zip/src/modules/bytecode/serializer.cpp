#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor bytecode_serializer() { return {"bytecode", "serializer", "Reserves portable bytecode serialization"}; }
}