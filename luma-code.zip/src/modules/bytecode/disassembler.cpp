#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor bytecode_disassembler() { return {"bytecode", "disassembler", "Reserves human-readable bytecode output"}; }
}