#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor ast_nodes() { return {"ast", "nodes", "Defines shared AST node conventions"}; }
}