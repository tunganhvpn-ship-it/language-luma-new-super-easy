#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor ast_visitors() { return {"ast", "visitors", "Defines extensible AST visitor contracts"}; }
}