#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor ast_expressions() { return {"ast", "expressions", "Defines expression node ownership"}; }
}