#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor ast_walking() { return {"ast", "walking", "Reserves ordered AST traversal"}; }
}