#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor ast_statements() { return {"ast", "statements", "Defines statement node ownership"}; }
}