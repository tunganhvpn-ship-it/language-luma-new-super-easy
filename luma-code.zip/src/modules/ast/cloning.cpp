#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor ast_cloning() { return {"ast", "cloning", "Reserves deep syntax tree copying"}; }
}