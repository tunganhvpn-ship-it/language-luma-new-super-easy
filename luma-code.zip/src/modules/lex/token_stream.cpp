#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor lex_token_stream() { return {"lex", "token_stream", "Defines token stream traversal"}; }
}