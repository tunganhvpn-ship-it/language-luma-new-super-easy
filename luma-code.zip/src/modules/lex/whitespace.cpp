#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor lex_whitespace() { return {"lex", "whitespace", "Owns whitespace normalization policy"}; }
}