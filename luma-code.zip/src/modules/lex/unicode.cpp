#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor lex_unicode() { return {"lex", "unicode", "Reserves Unicode lexer behavior"}; }
}