#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor lex_strings() { return {"lex", "strings", "Recognizes escaped text literals"}; }
}