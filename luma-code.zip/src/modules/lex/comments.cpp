#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor lex_comments() { return {"lex", "comments", "Recognizes line comment boundaries"}; }
}