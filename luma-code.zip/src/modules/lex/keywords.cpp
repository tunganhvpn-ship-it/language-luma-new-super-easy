#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor lex_keywords() { return {"lex", "keywords", "Maps reserved words to token kinds"}; }
}