#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor lex_indentation() { return {"lex", "indentation", "Converts layout into structural tokens"}; }
}