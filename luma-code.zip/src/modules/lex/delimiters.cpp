#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor lex_delimiters() { return {"lex", "delimiters", "Recognizes grouping delimiters"}; }
}