#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor parse_token_cursor() { return {"parse", "token_cursor", "Owns token cursor movement rules"}; }
}