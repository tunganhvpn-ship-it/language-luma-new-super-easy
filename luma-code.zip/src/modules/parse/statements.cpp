#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor parse_statements() { return {"parse", "statements", "Parses command-oriented statements"}; }
}