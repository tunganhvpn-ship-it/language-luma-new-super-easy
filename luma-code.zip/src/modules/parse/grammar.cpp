#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor parse_grammar() { return {"parse", "grammar", "Defines Luma grammar boundaries"}; }
}