#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor parse_context() { return {"parse", "context", "Captures parser context state"}; }
}