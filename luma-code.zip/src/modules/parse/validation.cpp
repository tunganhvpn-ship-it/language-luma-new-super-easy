#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor parse_validation() { return {"parse", "validation", "Validates parse-stage constraints"}; }
}