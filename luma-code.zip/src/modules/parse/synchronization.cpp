#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor parse_synchronization() { return {"parse", "synchronization", "Reserves parser synchronization points"}; }
}