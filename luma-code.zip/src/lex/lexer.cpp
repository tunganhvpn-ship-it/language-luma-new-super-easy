#include "luma/lex/lexer.hpp"

#include <cctype>
#include <string>
#include <unordered_map>

#include "luma/core/diagnostic.hpp"

namespace luma
{
    namespace
    {

        const std::unordered_map<std::string, TokenKind> keywords{
            // ── Python core keywords ────────────────────────────────────
            {"and",      TokenKind::and_keyword},
            {"as",       TokenKind::as_keyword},
            {"assert",   TokenKind::assert_keyword},
            {"async",    TokenKind::async_keyword},
            {"await",    TokenKind::await_keyword},
            {"break",    TokenKind::break_keyword},
            {"class",    TokenKind::class_keyword},
            {"continue", TokenKind::continue_keyword},
            {"def",      TokenKind::def_keyword},
            {"del",      TokenKind::del_keyword},
            {"elif",     TokenKind::elif_keyword},
            {"else",     TokenKind::else_keyword},
            {"except",   TokenKind::except_keyword},
            {"finally",  TokenKind::finally_keyword},
            {"for",      TokenKind::for_keyword},
            {"from",     TokenKind::from_keyword},
            {"global",   TokenKind::global_keyword},
            {"if",       TokenKind::if_keyword},
            {"import",   TokenKind::import_keyword},
            {"in",       TokenKind::in_keyword},
            {"is",       TokenKind::is_keyword},
            {"lambda",   TokenKind::lambda_keyword},
            {"nonlocal", TokenKind::nonlocal_keyword},
            {"not",      TokenKind::not_keyword},
            {"or",       TokenKind::or_keyword},
            {"pass",     TokenKind::pass_keyword},
            {"raise",    TokenKind::raise_keyword},
            {"return",   TokenKind::return_keyword},
            {"try",      TokenKind::try_keyword},
            {"while",    TokenKind::while_keyword},
            {"with",     TokenKind::with_keyword},
            {"yield",    TokenKind::yield_keyword},

            // ── Python literals ─────────────────────────────────────────
            {"True",  TokenKind::true_keyword},
            {"False", TokenKind::false_keyword},
            {"None",  TokenKind::none_keyword},

            // ── Legacy Luma compat (aliases) ────────────────────────────
            {"let",      TokenKind::identifier},  // will be handled in parser
            {"show",     TokenKind::identifier},  // will be handled in parser
            {"when",     TokenKind::if_keyword},  // alias for if
            {"otherwise", TokenKind::else_keyword}, // alias for else
            {"func",     TokenKind::def_keyword}, // alias for def
            {"repeat",   TokenKind::identifier},  // sugar for range()
            {"until",    TokenKind::while_keyword}, // sugar for while not
            {"forever",  TokenKind::while_keyword}, // sugar for while True
            {"nothing",  TokenKind::none_keyword}, // alias for None
            {"to",       TokenKind::identifier},  // handled in parser
            {"step",     TokenKind::identifier},  // handled in parser
        };

        bool is_identifier_start(char character)
        {
            return std::isalpha(static_cast<unsigned char>(character)) != 0 || character == '_';
        }

        bool is_identifier_part(char character)
        {
            return std::isalnum(static_cast<unsigned char>(character)) != 0 || character == '_';
        }

        // Check if a keyword is a Luma legacy alias that maps to an identifier.
        // These need special handling in the parser.
        bool is_luma_legacy_alias(const std::string &word)
        {
            return word == "let" || word == "show" || word == "repeat" ||
                   word == "to" || word == "step";
        }

    }

    Lexer::Lexer(std::string_view source) : source_(source) {}

    std::vector<Token> Lexer::scan() const
    {
        std::vector<Token> tokens;
        std::vector<std::size_t> indentation{0};
        std::size_t start = 0;
        std::size_t line_number = 1;

        while (start <= source_.size())
        {
            const auto end = source_.find('\n', start);
            const auto length = end == std::string_view::npos ? source_.size() - start : end - start;
            auto line = source_.substr(start, length);
            if (!line.empty() && line.back() == '\r')
            {
                line.remove_suffix(1);
            }

            std::size_t indent = 0;
            while (indent < line.size() && line[indent] == ' ')
            {
                ++indent;
            }
            if (indent < line.size() && line[indent] == '\t')
            {
                fail("Use spaces for indentation, not tabs", {line_number, indent + 1});
            }
            const auto content = line.substr(indent);
            if (!content.empty() && content.front() != '#')
            {
                if (indent > indentation.back())
                {
                    indentation.push_back(indent);
                    tokens.push_back({TokenKind::indent, "", {line_number, 1}});
                }
                while (indent < indentation.back())
                {
                    indentation.pop_back();
                    tokens.push_back({TokenKind::dedent, "", {line_number, 1}});
                }
                if (indent != indentation.back())
                {
                    fail("Indentation does not match any outer block", {line_number, 1});
                }

                std::size_t current = indent;
                while (current < line.size())
                {
                    const char character = line[current];
                    const SourceLocation location{line_number, current + 1};

                    // ── Whitespace ─────────────────────────────────────
                    if (character == ' ' || character == '\r')
                    {
                        ++current;
                    }
                    // ── Comment ─────────────────────────────────────────
                    else if (character == '#')
                    {
                        break;
                    }
                    // ── Identifier / Keyword ────────────────────────────
                    else if (is_identifier_start(character))
                    {
                        const auto first = current++;
                        while (current < line.size() && is_identifier_part(line[current]))
                        {
                            ++current;
                        }
                        const std::string word{line.substr(first, current - first)};
                        const auto keyword = keywords.find(word);
                        if (keyword != keywords.end())
                        {
                            // Legacy Luma aliases: treat as identifier, parser handles them
                            if (is_luma_legacy_alias(word))
                                tokens.push_back({TokenKind::identifier, word, location});
                            else
                                tokens.push_back({keyword->second, word, location});
                        }
                        else
                        {
                            tokens.push_back({TokenKind::identifier, word, location});
                        }
                    }
                    // ── Number ──────────────────────────────────────────
                    else if (std::isdigit(static_cast<unsigned char>(character)) != 0)
                    {
                        const auto first = current++;
                        bool decimal = false;
                        while (current < line.size() &&
                               (std::isdigit(static_cast<unsigned char>(line[current])) != 0 ||
                                (line[current] == '.' && !decimal)))
                        {
                            decimal = decimal || line[current] == '.';
                            ++current;
                        }
                        // Handle scientific notation: 1e10, 1.5E-3
                        if (current < line.size() && (line[current] == 'e' || line[current] == 'E'))
                        {
                            ++current;
                            if (current < line.size() && (line[current] == '+' || line[current] == '-'))
                                ++current;
                            while (current < line.size() &&
                                   std::isdigit(static_cast<unsigned char>(line[current])) != 0)
                                ++current;
                        }
                        tokens.push_back({TokenKind::number, std::string{line.substr(first, current - first)}, location});
                    }
                    // ── F-string (f"..." or f'...') ────────────────────
                    else if ((character == 'f' || character == 'F') &&
                             current + 1 < line.size() &&
                             (line[current + 1] == '"' || line[current + 1] == '\''))
                    {
                        const char quote = line[current + 1];
                        ++current; // skip 'f'
                        ++current; // skip opening quote

                        // Check for triple-quote
                        bool triple = false;
                        if (current + 2 < line.size() &&
                            line[current] == quote && line[current + 1] == quote)
                        {
                            triple = true;
                            current += 2; // skip triple quotes
                        }

                        std::string text;
                        bool closed = false;
                        while (current < line.size())
                        {
                            const char value = line[current];
                            if (triple)
                            {
                                if (value == quote && current + 2 < line.size() &&
                                    line[current + 1] == quote && line[current + 2] == quote)
                                {
                                    current += 3;
                                    closed = true;
                                    break;
                                }
                                text += value;
                                ++current;
                            }
                            else
                            {
                                if (value == quote)
                                {
                                    ++current;
                                    closed = true;
                                    break;
                                }
                                if (value == '\\' && current + 1 < line.size())
                                {
                                    text += value;
                                    text += line[current + 1];
                                    current += 2;
                                }
                                else
                                {
                                    text += value;
                                    ++current;
                                }
                            }
                        }
                        if (!closed)
                        {
                            fail("F-string is missing its closing quote", location);
                        }
                        TokenKind kind = triple ? TokenKind::long_fstring : TokenKind::fstring;
                        tokens.push_back({kind, std::move(text), location});
                    }
                    // ── Triple-quoted string ────────────────────────────
                    else if ((character == '"' || character == '\'') &&
                             current + 2 < line.size() &&
                             line[current + 1] == character && line[current + 2] == character)
                    {
                        const char quote = character;
                        current += 3; // skip opening triple quotes
                        std::string text;
                        bool closed = false;
                        while (current + 2 < line.size())
                        {
                            if (line[current] == quote && line[current + 1] == quote && line[current + 2] == quote)
                            {
                                current += 3;
                                closed = true;
                                break;
                            }
                            if (line[current] == '\\' && current + 1 < line.size())
                            {
                                text += line[current + 1];
                                current += 2;
                            }
                            else
                            {
                                text += line[current];
                                ++current;
                            }
                        }
                        if (!closed)
                        {
                            fail("Multi-line text is missing its closing triple quotes", location);
                        }
                        tokens.push_back({TokenKind::long_text, std::move(text), location});
                    }
                    // ── String ──────────────────────────────────────────
                    else if (character == '\"' || character == '\'')
                    {
                        const char quote = character;
                        ++current;
                        std::string text;
                        bool closed = false;
                        while (current < line.size())
                        {
                            const char value = line[current++];
                            if (value == quote)
                            {
                                closed = true;
                                break;
                            }
                            if (value == '\\' && current < line.size())
                            {
                                const char escaped = line[current++];
                                switch (escaped)
                                {
                                case 'n':  text += '\n'; break;
                                case 't':  text += '\t'; break;
                                case 'r':  text += '\r'; break;
                                case '\\': text += '\\'; break;
                                case '\'': text += '\''; break;
                                case '"':  text += '"'; break;
                                case '0':  text += '\0'; break;
                                default:   text += escaped; break;
                                }
                            }
                            else
                            {
                                text += value;
                            }
                        }
                        if (!closed)
                        {
                            fail("Text value is missing its closing quote", location);
                        }
                        tokens.push_back({TokenKind::text, std::move(text), location});
                    }
                    // ── Operators and delimiters ────────────────────────
                    else
                    {
                        const auto peek = [&](std::size_t offset) -> char {
                            return (current + offset < line.size()) ? line[current + offset] : '\0';
                        };

                        TokenKind kind{};
                        std::size_t width = 1;

                        switch (character)
                        {
                        // ── Single-char delimiters ──────────────────────
                        case '(':
                            kind = TokenKind::left_paren;
                            break;
                        case ')':
                            kind = TokenKind::right_paren;
                            break;
                        case '[':
                            kind = TokenKind::left_bracket;
                            break;
                        case ']':
                            kind = TokenKind::right_bracket;
                            break;
                        case '{':
                            kind = TokenKind::left_brace;
                            break;
                        case '}':
                            kind = TokenKind::right_brace;
                            break;
                        case ',':
                            kind = TokenKind::comma;
                            break;
                        case ';':
                            kind = TokenKind::semicolon;
                            break;
                        case '~':
                            kind = TokenKind::tilde;
                            break;

                        // ── Colon / Walrus ──────────────────────────────
                        case ':':
                            if (peek(1) == '=')
                            {
                                kind = TokenKind::walrus;
                                width = 2;
                            }
                            else
                            {
                                kind = TokenKind::colon;
                            }
                            break;

                        // ── Dot / Ellipsis ──────────────────────────────
                        case '.':
                            if (peek(1) == '.' && peek(2) == '.')
                            {
                                kind = TokenKind::ellipsis;
                                width = 3;
                            }
                            else
                            {
                                kind = TokenKind::dot;
                            }
                            break;

                        // ── At / Decorator / Matrix multiply ────────────
                        case '@':
                            if (peek(1) == '=')
                            {
                                kind = TokenKind::at_equal;
                                width = 2;
                            }
                            else
                            {
                                kind = TokenKind::at;
                            }
                            break;

                        // ── Plus / Increment ────────────────────────────
                        case '+':
                            if (peek(1) == '+')
                            {
                                kind = TokenKind::plus_plus;
                                width = 2;
                            }
                            else if (peek(1) == '=')
                            {
                                kind = TokenKind::plus_equal;
                                width = 2;
                            }
                            else
                            {
                                kind = TokenKind::plus;
                            }
                            break;

                        // ── Minus / Decrement / Arrow ───────────────────
                        case '-':
                            if (peek(1) == '-')
                            {
                                kind = TokenKind::minus_minus;
                                width = 2;
                            }
                            else if (peek(1) == '=')
                            {
                                kind = TokenKind::minus_equal;
                                width = 2;
                            }
                            else if (peek(1) == '>')
                            {
                                kind = TokenKind::arrow;
                                width = 2;
                            }
                            else
                            {
                                kind = TokenKind::minus;
                            }
                            break;

                        // ── Star / Power / Star-equal ───────────────────
                        case '*':
                            if (peek(1) == '*')
                            {
                                if (peek(2) == '=')
                                {
                                    kind = TokenKind::star_star_equal;
                                    width = 3;
                                }
                                else
                                {
                                    kind = TokenKind::star_star;
                                    width = 2;
                                }
                            }
                            else if (peek(1) == '=')
                            {
                                kind = TokenKind::star_equal;
                                width = 2;
                            }
                            else
                            {
                                kind = TokenKind::star;
                            }
                            break;

                        // ── Slash / Floor divide ────────────────────────
                        case '/':
                            if (peek(1) == '/')
                            {
                                if (peek(2) == '=')
                                {
                                    kind = TokenKind::double_slash_equal;
                                    width = 3;
                                }
                                else
                                {
                                    kind = TokenKind::double_slash;
                                    width = 2;
                                }
                            }
                            else if (peek(1) == '=')
                            {
                                kind = TokenKind::slash_equal;
                                width = 2;
                            }
                            else
                            {
                                kind = TokenKind::slash;
                            }
                            break;

                        // ── Percent ─────────────────────────────────────
                        case '%':
                            if (peek(1) == '=')
                            {
                                kind = TokenKind::percent_equal;
                                width = 2;
                            }
                            else
                            {
                                kind = TokenKind::percent;
                            }
                            break;

                        // ── Equal / Equal-equal ─────────────────────────
                        case '=':
                            if (peek(1) == '=')
                            {
                                kind = TokenKind::equal_equal;
                                width = 2;
                            }
                            else
                            {
                                kind = TokenKind::equal;
                            }
                            break;

                        // ── Bang / Not-equal ────────────────────────────
                        case '!':
                            if (peek(1) == '=')
                            {
                                kind = TokenKind::bang_equal;
                                width = 2;
                            }
                            else
                            {
                                fail("Use 'not' for logical negation, or '!=' for not equal", location);
                            }
                            break;

                        // ── Less / Less-equal / Left-shift ──────────────
                        case '<':
                            if (peek(1) == '=')
                            {
                                kind = TokenKind::less_equal;
                                width = 2;
                            }
                            else if (peek(1) == '<')
                            {
                                kind = TokenKind::left_shift;
                                width = 2;
                            }
                            else
                            {
                                kind = TokenKind::less;
                            }
                            break;

                        // ── Greater / Greater-equal / Right-shift ───────
                        case '>':
                            if (peek(1) == '=')
                            {
                                kind = TokenKind::greater_equal;
                                width = 2;
                            }
                            else if (peek(1) == '>')
                            {
                                kind = TokenKind::right_shift;
                                width = 2;
                            }
                            else
                            {
                                kind = TokenKind::greater;
                            }
                            break;

                        // ── Ampersand / Bitwise AND ─────────────────────
                        case '&':
                            kind = TokenKind::ampersand;
                            break;

                        // ── Pipe / Bitwise OR ───────────────────────────
                        case '|':
                            kind = TokenKind::pipe;
                            break;

                        // ── Caret / Bitwise XOR ─────────────────────────
                        case '^':
                            kind = TokenKind::caret;
                            break;

                        default:
                            fail(std::string{"I do not understand '"} + character + "'", location);
                        }
                        tokens.push_back({kind, std::string{line.substr(current, width)}, location});
                        current += width;
                    }
                }
                tokens.push_back({TokenKind::newline, "", {line_number, line.size() + 1}});
            }

            if (end == std::string_view::npos)
                break;
            start = end + 1;
            ++line_number;
        }

        while (indentation.size() > 1)
        {
            indentation.pop_back();
            tokens.push_back({TokenKind::dedent, "", {line_number, 1}});
        }
        tokens.push_back({TokenKind::end, "", {line_number, 1}});
        return tokens;
    }

}
