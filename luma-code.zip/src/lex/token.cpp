#include "luma/lex/token.hpp"

namespace luma
{

    std::string_view token_name(TokenKind kind)
    {
        switch (kind)
        {
        // ── Structural ──────────────────────────────────────────────────
        case TokenKind::end:
            return "end of file";
        case TokenKind::newline:
            return "new line";
        case TokenKind::indent:
            return "indent";
        case TokenKind::dedent:
            return "dedent";

        // ── Literals and names ──────────────────────────────────────────
        case TokenKind::identifier:
            return "name";
        case TokenKind::number:
            return "number";
        case TokenKind::text:
            return "text";
        case TokenKind::fstring:
            return "f-string";
        case TokenKind::long_text:
            return "multi-line text";
        case TokenKind::long_fstring:
            return "multi-line f-string";

        // ── Python keywords ─────────────────────────────────────────────
        case TokenKind::and_keyword:
            return "and";
        case TokenKind::as_keyword:
            return "as";
        case TokenKind::assert_keyword:
            return "assert";
        case TokenKind::async_keyword:
            return "async";
        case TokenKind::await_keyword:
            return "await";
        case TokenKind::break_keyword:
            return "break";
        case TokenKind::class_keyword:
            return "class";
        case TokenKind::continue_keyword:
            return "continue";
        case TokenKind::def_keyword:
            return "def";
        case TokenKind::del_keyword:
            return "del";
        case TokenKind::elif_keyword:
            return "elif";
        case TokenKind::else_keyword:
            return "else";
        case TokenKind::except_keyword:
            return "except";
        case TokenKind::finally_keyword:
            return "finally";
        case TokenKind::for_keyword:
            return "for";
        case TokenKind::from_keyword:
            return "from";
        case TokenKind::global_keyword:
            return "global";
        case TokenKind::if_keyword:
            return "if";
        case TokenKind::import_keyword:
            return "import";
        case TokenKind::in_keyword:
            return "in";
        case TokenKind::is_keyword:
            return "is";
        case TokenKind::lambda_keyword:
            return "lambda";
        case TokenKind::nonlocal_keyword:
            return "nonlocal";
        case TokenKind::not_keyword:
            return "not";
        case TokenKind::or_keyword:
            return "or";
        case TokenKind::pass_keyword:
            return "pass";
        case TokenKind::raise_keyword:
            return "raise";
        case TokenKind::return_keyword:
            return "return";
        case TokenKind::try_keyword:
            return "try";
        case TokenKind::while_keyword:
            return "while";
        case TokenKind::with_keyword:
            return "with";
        case TokenKind::yield_keyword:
            return "yield";

        // ── Python literals ─────────────────────────────────────────────
        case TokenKind::true_keyword:
            return "True";
        case TokenKind::false_keyword:
            return "False";
        case TokenKind::none_keyword:
            return "None";

        // ── Delimiters ──────────────────────────────────────────────────
        case TokenKind::left_paren:
            return "(";
        case TokenKind::right_paren:
            return ")";
        case TokenKind::left_bracket:
            return "[";
        case TokenKind::right_bracket:
            return "]";
        case TokenKind::left_brace:
            return "{";
        case TokenKind::right_brace:
            return "}";
        case TokenKind::colon:
            return ":";
        case TokenKind::semicolon:
            return ";";
        case TokenKind::comma:
            return ",";
        case TokenKind::dot:
            return ".";
        case TokenKind::at:
            return "@";
        case TokenKind::arrow:
            return "->";
        case TokenKind::ellipsis:
            return "...";
        case TokenKind::walrus:
            return ":=";

        // ── Operators ───────────────────────────────────────────────────
        case TokenKind::plus:
            return "+";
        case TokenKind::minus:
            return "-";
        case TokenKind::star:
            return "*";
        case TokenKind::star_star:
            return "**";
        case TokenKind::slash:
            return "/";
        case TokenKind::double_slash:
            return "//";
        case TokenKind::percent:
            return "%";
        case TokenKind::at_op:
            return "@";

        // ── Assignment operators ────────────────────────────────────────
        case TokenKind::equal:
            return "=";
        case TokenKind::plus_equal:
            return "+=";
        case TokenKind::minus_equal:
            return "-=";
        case TokenKind::star_equal:
            return "*=";
        case TokenKind::slash_equal:
            return "/=";
        case TokenKind::double_slash_equal:
            return "//=";
        case TokenKind::percent_equal:
            return "%=";
        case TokenKind::star_star_equal:
            return "**=";
        case TokenKind::at_equal:
            return "@=";

        // ── Comparison operators ────────────────────────────────────────
        case TokenKind::equal_equal:
            return "==";
        case TokenKind::bang_equal:
            return "!=";
        case TokenKind::less:
            return "<";
        case TokenKind::less_equal:
            return "<=";
        case TokenKind::greater:
            return ">";
        case TokenKind::greater_equal:
            return ">=";

        // ── Bitwise operators ───────────────────────────────────────────
        case TokenKind::ampersand:
            return "&";
        case TokenKind::pipe:
            return "|";
        case TokenKind::caret:
            return "^";
        case TokenKind::tilde:
            return "~";
        case TokenKind::left_shift:
            return "<<";
        case TokenKind::right_shift:
            return ">>";

        // ── Increment/Decrement ─────────────────────────────────────────
        case TokenKind::plus_plus:
            return "++";
        case TokenKind::minus_minus:
            return "--";
        }
        return "unknown";
    }

}
