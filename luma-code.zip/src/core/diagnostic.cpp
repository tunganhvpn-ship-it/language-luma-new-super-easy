#include "luma/core/diagnostic.hpp"

#include <utility>

namespace luma
{

    Diagnostic::Diagnostic(std::string message, SourceLocation location)
        : std::runtime_error("Line " + std::to_string(location.line) + ", column " +
                             std::to_string(location.column) + ": " + message),
          location_(location) {}

    const SourceLocation &Diagnostic::location() const noexcept
    {
        return location_;
    }

    void fail(std::string message, SourceLocation location)
    {
        throw Diagnostic(std::move(message), location);
    }

}